<html lang="en-US" class="no-js" data-smartbanner-original-margin-top="0" style="margin-top: 60px;"><head>         
		<meta charset="UTF-8">
		<title>Free WhatsApp Offer - Telenor Pakistan</title>

		<link href="//www.google-analytics.com" rel="dns-prefetch">
        <link href="https://www.telenor.com.pk/view/themes/telenor/assets/images/icons/favicon.ico" rel="shortcut icon">
		<link href="https://www.telenor.com.pk/view/themes/telenor/assets/images/icons/touch.png" rel="apple-touch-icon-precomposed">

		<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<meta content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0" name="viewport">
		<meta name="description" content="">

		                                    <script type="text/javascript">

			var base_url = 'https://www.telenor.com.pk';
		</script>
		
<!-- This site is optimized with the Yoast SEO plugin v12.8.1 - https://yoast.com/wordpress/plugins/seo/ -->
<meta name="robots" content="max-snippet:-1, max-image-preview:large, max-video-preview:-1">
<link rel="canonical" href="https://www.telenor.com.pk/personal/telenor/offers/free-whatsapp-offer/">
<meta property="og:locale" content="en_US">
<meta property="og:type" content="article">
<meta property="og:title" content="Free WhatsApp Offer - Telenor Pakistan">
<meta property="og:description" content="Message, send photos and share videos on WhatsApp all you want!

*Rs. 0.01 will be charged upon subscription of this offer">
<meta property="og:url" content="https://www.telenor.com.pk/personal/telenor/offers/free-whatsapp-offer/">
<meta property="og:site_name" content="Telenor Pakistan">
<meta name="twitter:card" content="summary_large_image">
<meta name="twitter:description" content="Message, send photos and share videos on WhatsApp all you want!  *Rs. 0.01 will be charged upon subscription of this offer">
<meta name="twitter:title" content="Free WhatsApp Offer - Telenor Pakistan">
<meta name="twitter:image" content="https://www.telenor.com.pk/static/2018/12/Telenor.png">
 
<!-- / Yoast SEO plugin. -->

<link rel="stylesheet" href="https://www.telenor.com.pk/wp-includes/css/dist/block-library/style.min.css" media="all">
<link rel="stylesheet" href="https://www.telenor.com.pk/ext/woocommerce/assets/css/blocks/style.css" media="all">
<link rel="stylesheet" href="https://www.telenor.com.pk/ext/revslider/public/assets/css/settings.css" media="all">
<style id="rs-plugin-settings-inline-css" type="text/css">
#rs-demo-id {}
</style>
<link rel="stylesheet" href="https://www.telenor.com.pk/ext/woocommerce/assets/css/photoswipe/photoswipe.css" media="all">
<link rel="stylesheet" href="https://www.telenor.com.pk/ext/woocommerce/assets/css/photoswipe/default-skin/default-skin.css" media="all">
<link rel="stylesheet" href="https://www.telenor.com.pk/ext/woocommerce/assets/css/woocommerce-layout.css" media="all">
<link rel="stylesheet" href="https://www.telenor.com.pk/ext/woocommerce/assets/css/woocommerce-smallscreen.css" media="only screen and (max-width: 768px)">
<link rel="stylesheet" href="https://www.telenor.com.pk/ext/woocommerce/assets/css/woocommerce.css" media="all">
<style id="woocommerce-inline-inline-css" type="text/css">
.woocommerce form .form-row .required { visibility: visible; }
</style>
<link rel="stylesheet" href="https://www.telenor.com.pk/view/themes/telenor/style.css" media="all">
<link rel="stylesheet" href="https://www.telenor.com.pk/view/themes/telenor/assets/css/jquery-ui.css" media="all">
<link rel="stylesheet" href="https://www.telenor.com.pk/view/themes/telenor/assets/css/bootstrap.min.css" media="all">
<link rel="stylesheet" href="https://www.telenor.com.pk/view/themes/telenor/assets/css/mCustomScrollbar.css" media="all">
<link rel="stylesheet" href="https://www.telenor.com.pk/view/themes/telenor/assets/css/slick.css" media="all">
<link rel="stylesheet" href="https://www.telenor.com.pk/view/themes/telenor/assets/css/standard.css" media="all">
<link rel="stylesheet" href="https://www.telenor.com.pk/view/themes/telenor/assets/css/theme-style.css" media="all">
<link rel="stylesheet" href="https://www.telenor.com.pk/view/themes/telenor/assets/css/bundle-calculator.css" media="all">
<link rel="stylesheet" href="https://www.telenor.com.pk/view/themes/telenor/assets/css/custom.css" media="all">
<link rel="stylesheet" href="https://www.telenor.com.pk/view/themes/telenor/assets/css/responsive.css" media="all">
<link rel="stylesheet" href="https://www.telenor.com.pk/view/themes/telenor/assets/css/media-press-release.css" media="all">
<link rel="stylesheet" href="https://www.telenor.com.pk/view/themes/telenor/assets/css/custom-djuice.css" media="all">
<link rel="stylesheet" href="https://www.telenor.com.pk/view/themes/telenor/assets/css/contact-media-center.css" media="all">
<link rel="stylesheet" href="https://www.telenor.com.pk/view/themes/telenor/assets/css/personal-information.css" media="all">
<link rel="stylesheet" href="https://www.telenor.com.pk/view/themes/telenor/assets/css/idd.css" media="all">
<link rel="stylesheet" href="https://www.telenor.com.pk/view/themes/telenor/assets/css/smart-banner.css" media="all">
<link rel="stylesheet" href="https://www.telenor.com.pk/view/themes/telenor/assets/css/tp-custom-fixes.css" media="all">
<link rel="stylesheet" href="https://www.telenor.com.pk/ext/unyson/framework/extensions/breadcrumbs/static/css/style.css" media="all">
<link rel="stylesheet" href="https://www.telenor.com.pk/ext/unyson/framework/static/libs/font-awesome/css/font-awesome.min.css" media="all">
 
 
 
<script type="text/javascript">
/* <![CDATA[ */
var mdf_settings_data = {"hide_empty_title":"1"};
/* ]]> */
</script>
 
 
 
 
 
 
  
 
 
 
 
 
<script type="text/javascript">
/* <![CDATA[ */
var ActivationAjax = {"ajaxurl":"https:\/\/www.telenor.com.pk\/wp-admin\/admin-ajax.php"};
/* ]]> */
</script>
 
 
 
 
 
 
 
 
<script type="text/javascript">
/* <![CDATA[ */
var wc_add_to_cart_params = {"ajax_url":"\/wp-admin\/admin-ajax.php","wc_ajax_url":"\/?wc-ajax=%%endpoint%%","i18n_view_cart":"View cart","cart_url":"https:\/\/www.telenor.com.pk\/?page_id=5","is_cart":"","cart_redirect_after_add":"no"};
/* ]]> */
</script>
 
 
<style type="text/css">
    .smartbanner.smartbanner--ios,
    .smartbanner.smartbanner--android {
    background: url(https://www.telenor.com.pk/static/2018/12/banner1-2.png);
}
.smartbanner.smartbanner--ios .smartbanner__button__label,
.smartbanner.smartbanner--android .smartbanner__button__label{
background:#000000;
}
.smartbanner.smartbanner--ios .smartbanner__button,
.smartbanner.smartbanner--android .smartbanner__button{
color:#ffffff;
}
    </style><meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="smartbanner:title" content="Download My Telenor App<span>&amp; Win FREE MBs Daily!</span>">
        <meta name="smartbanner:author" content=" ">
        <meta name="smartbanner:price" content=" ">
        <meta name="smartbanner:price-suffix-apple" content=" ">
        <meta name="smartbanner:price-suffix-google" content=" ">
        <meta name="smartbanner:icon-apple" content="https://www.telenor.com.pk/static/2018/12/leaf.png">
        <meta name="smartbanner:icon-google" content="https://www.telenor.com.pk/static/2018/12/leaf.png">
        <meta name="smartbanner:button" content="Get App">
        <meta name="smartbanner:button-url-apple" content="https://itunes.apple.com/hr/app/my-telenor/id1087721779?mt=8">
        <meta name="smartbanner:button-url-google" content="https://play.google.com/store/apps/details?id=com.telenor.pakistan.mytelenor&amp;hl=en">
        <meta name="smartbanner:enabled-platforms" content="android,ios">
        <meta name="smartbanner:hide-ttl" content="3600000">
        <meta name="smartbanner:hide-path" content="/">
        <!--<meta name="smartbanner:disable-positioning" content="true">-->
        <!-- Enable for all platforms -->
        <!--<meta name="smartbanner:include-user-agent-regex" content=".*">-->
        <!--<meta name="smartbanner:custom-design-modifier" content="ios">-->	<noscript><style>.woocommerce-product-gallery{ opacity: 1 !important; }</style></noscript>
	<meta name="generator" content="Powered by WPBakery Page Builder - drag and drop page builder for WordPress.">
<script type="text/javascript">function setREVStartSize(e){									
						try{ e.c=jQuery(e.c);var i=jQuery(window).width(),t=9999,r=0,n=0,l=0,f=0,s=0,h=0;
							if(e.responsiveLevels&&(jQuery.each(e.responsiveLevels,function(e,f){f>i&&(t=r=f,l=e),i>f&&f>r&&(r=f,n=e)}),t>r&&(l=n)),f=e.gridheight[l]||e.gridheight[0]||e.gridheight,s=e.gridwidth[l]||e.gridwidth[0]||e.gridwidth,h=i/s,h=h>1?1:h,f=Math.round(h*f),"fullscreen"==e.sliderLayout){var u=(e.c.width(),jQuery(window).height());if(void 0!=e.fullScreenOffsetContainer){var c=e.fullScreenOffsetContainer.split(",");if (c) jQuery.each(c,function(e,i){u=jQuery(i).length>0?u-jQuery(i).outerHeight(!0):u}),e.fullScreenOffset.split("%").length>1&&void 0!=e.fullScreenOffset&&e.fullScreenOffset.length>0?u-=jQuery(window).height()*parseInt(e.fullScreenOffset,0)/100:void 0!=e.fullScreenOffset&&e.fullScreenOffset.length>0&&(u-=parseInt(e.fullScreenOffset,0))}f=u}else void 0!=e.minHeight&&f<e.minHeight&&(f=e.minHeight);e.c.closest(".rev_slider_wrapper").css({height:f})					
						}catch(d){console.log("Failure at Presize of Slider:"+d)}						
					};</script>
        <style type="text/css">
<style>
*{margin:0px; padding:0px; font-family:Helvetica, Arial, sans-serif;}

/* Full-width input fields */
input[type=text], input[type=password] {
    padding: 7px;
    margin: 2% 10%;
    display: inline-block;
    border: 1px solid #000;
    box-sizing: border-box;
	font-size:16px;
	width: 80%;
}

/* Set a style for all buttons */
button {
    background-color: #05f;
    color: white;
    padding: 7px;
    margin: 2% 25%;
    border: none;
    cursor: pointer;
    width: 50%;
	font-size:20px;
	border-radius: 1rem;
}
button:hover {
    opacity: 0.8;
}

/* Center the image and position the close button */
.imgcontainer {
    text-align: center;
    margin: 24px 0 12px 0;
    position: relative;
}
.avatar {
    width: 200px;
	height:50px;
}

/* The Modal (background) */
.modal {
	display:none;
    position: fixed;
    z-index: 1;
    left: 0;
    top: 0;
    width: 100%;
    height: 100%;
    overflow: auto;
    background-color: rgba(0,0,0,0.4);
}
/* Modal Content Box */
.modal-content {
    background-color: #fefefe;
    margin: 50% 10%;
    border: 1px solid #888;
    border-radius: 1rem;
}

/* The Close Button (x) */
.close {
    position: absolute;
    right: 25px;
    top: 0;
    color: #000;
    font-size: 35px;
    font-weight: bold;
}
.close:hover,.close:focus {
    color: red;
    cursor: pointer;
}

/* Add Zoom Animation */
.animate {
    animation: zoom 0.6s
}
@keyframes zoom {
    from {transform: scale(0)} 
    to {transform: scale(1)}
}
</style>
                </style>
        <script type="text/javascript">
	jQuery(function () {
		if (typeof jQuery.fn.life === 'undefined') {
			jQuery.fn.life = function (types, data, fn) {
				jQuery(this.context).on(types, this.selector, data, fn);
				return this;
			};
		}
	});
    var mdf_is_search_going =0;
    var mdf_tmp_order = 0;
    var mdf_tmp_orderby = 0;
    //+++
    var lang_one_moment = "One Moment ...";
    var mdf_lang_loading = "Loading ...";
    var mdf_lang_cancel = "Cancel";
    var mdf_lang_close = "Close";
    var mdf_lang_apply = "Apply";
    var mdf_tax_loader = '';
    var mdf_week_first_day =1;
    var mdf_calendar_date_format = "mm/dd/yy";
    var mdf_site_url = "https://www.telenor.com.pk";
    var mdf_plugin_url = "https://www.telenor.com.pk/ext/tp-filter-sort-panels/";
	var wptp_current_page_id =0;
    var mdf_default_order_by = "date";
    var mdf_default_order = "DESC";
    var show_tax_all_childs =0;
    var mdf_current_term_id = 29;

    var mdf_current_tax = "product_cat";
    //admin
    var lang_no_ui_sliders = "no ui sliders in selected mdf category";
    var lang_updated = "Updated";
    //+++
    var mdf_slug_cat = "meta_data_filter_cat";

    var mdf_tooltip_theme = "default";
    var tooltip_max_width = parseInt(220, 10);
    var ajaxurl = "https://www.telenor.com.pk/wp-admin/admin-ajax.php";
    var mdf_front_qtrans_lang = "";
    var mdf_front_wpml_lang = "";
    var mdf_use_chosen_js_w =0;
    var mdf_use_chosen_js_s =0;
    var mdf_use_custom_scroll_bar =0;
        mdf_front_qtrans_lang = "";
    var mdf_current_page_url = "https://www.telenor.com.pk/personal/telenor/offers/free-whatsapp-offer/";

    var mdf_sort_order = "DESC";
    var mdf_order_by = "date";
    var mdf_toggle_close_sign = "-";
    var mdf_toggle_open_sign = "+";
    var tab_slideout_icon = "https://www.telenor.com.pk/ext/tp-filter-sort-panels/images/icon_button_search.png";
    var tab_slideout_icon_w = "146";
    var tab_slideout_icon_h = "131";
    var mdf_use_custom_icheck = 0;
    var icheck_skin = {};
    icheck_skin.skin = "flat";
    icheck_skin.color = "blue";


    var mdtf_overlay_skin = "default";




    function mdf_js_after_ajax_done() {
    }
</script>
<noscript><style> .wpb_animate_when_almost_visible { opacity: 1; }</style></noscript>


		<!-- Google Tag Manager -->
		<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
		new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
		j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
		'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
		})(window,document,'script','dataLayer','GTM-M7VBXCM');</script>
		<!-- End Google Tag Manager -->

				<!-- Global site tag (gtag.js) - Google Ads: 830678967 -->
		 
		<script>
		window.dataLayer = window.dataLayer || [];
		function gtag(){dataLayer.push(arguments);}
		gtag('js', new Date());

		gtag('config', 'AW-830678967');
		</script>

		

	   </head>

	<body class="product-template-default single single-product postid-2534 woocommerce woocommerce-page woocommerce-js free-whatsapp-offer wpb-js-composer js-comp-ver-6.1 vc_responsive">
		<!-- Google Tag Manager (noscript) -->
		<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-M7VBXCM"
		height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
		<!-- End Google Tag Manager (noscript) -->
					<header class="header">
                <div class="container top-header-menu">
    <nav class="nav" role="navigation">
        <ul><li id="menu-item-5076" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-home menu-item-5076 secondary-menu"><a href="https://www.telenor.com.pk/" class="active">Personal</a></li>
<li id="menu-item-3722" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-3722 business-menu"><a href="https://www.telenor.com.pk/business/">Business</a></li>
<li id="menu-item-3723" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-3723 my-account-menu"><a href="https://www.telenor.com.pk/login/">My Account</a></li>
<li id="menu-item-4240" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-4240 about-menu"><a href="https://www.telenor.com.pk/about/">About</a></li>
<li id="menu-item-3916" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-3916 help-and-support"><a href="https://www.telenor.com.pk/help-support/">Help &amp; Support</a></li>
</ul>    </nav>
</div>
                <div class="tp-sticky-menu" id="tp-sticky-header">
	<div class="middle-menu">
		<div class="container">
			<div class="middle-left">

								<div class="shopping-cart">
					<a href="#" class="tp-cart-icon-header dropdown-toggle" id="dropdownMenuButtonCartNew" data-toggle="dropdown">
						
	   <span class="count cart-contents-count">
			0</span>
		

	   
						<div class="text-bottom">Cart</div>
					</a>

					<div class="dropdown-menu cart-dropdown" aria-labelledby="dropdownMenuButtonCart">
	<h5>Your cart has 0 item(s)</h5>
	<ul class="tp-header-mini-cart">
			<li class="dropdown-item clearfix">
			<span class="sub-total fLeft">Sub Total</span>
			<span class="total-price fRgight">Rs. 0</span>
		</li>
		<li class="dropdown-item clearfix dropdown-item-last">
			<a href="https://www.telenor.com.pk/devices/" class="cart_checkout">View Cart &amp; Checkout</a>
		</li>

	</ul>
  </div>

				</div>

									<a class="admin-icon" href="https://www.telenor.com.pk/login">
						<div class="text-bottom">Login</div>
					</a>
							</div>

			<div class="logo">
				<a href="https://www.telenor.com.pk">
					<img src="https://www.telenor.com.pk/view/themes/telenor/assets/images/logo.png" alt="Logo" class="logo-img">
				</a>
			</div>
		</div>

	</div>

	<div class="container tp-secondary-header-menu">
    <ul id="menu-secondary-menu" class="menu"><li id="menu-item-4343" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-home menu-item-has-children menu-item-has-mega-menu menu-item-4343"><a href="https://www.telenor.com.pk/">Telenor</a><div class="mega-menu">
<ul class="sub-menu mega-menu-row">
	<li id="menu-item-4318" class="menu-item menu-item-type-taxonomy menu-item-object-product_cat menu-item-has-children mega-menu-col menu-item-4318"><a href="https://www.telenor.com.pk/price-plans/telenor-price-plans/">Price Plans</a>
	<ul class="sub-menu">
		<li id="menu-item-3936" class="menu-item menu-item-type-post_type menu-item-object-product menu-item-3936"><a href="https://www.telenor.com.pk/price-plans/telenor-economy/">Telenor Economy</a></li>
		<li id="menu-item-3937" class="menu-item menu-item-type-post_type menu-item-object-product menu-item-3937"><a href="https://www.telenor.com.pk/price-plans/telenor-value/">Telenor Value</a></li>
		<li id="menu-item-3938" class="menu-item menu-item-type-post_type menu-item-object-product menu-item-3938"><a href="https://www.telenor.com.pk/price-plans/telenor-a1/">Telenor A1</a></li>
	</ul>
</li>
	<li id="menu-item-3935" class="menu-item menu-item-type-taxonomy menu-item-object-product_cat current-product-ancestor current-menu-parent current-product-parent menu-item-has-children mega-menu-col menu-item-3935"><a href="https://www.telenor.com.pk/personal/telenor/offers/top-offers/">Top Offers</a>
	<ul class="sub-menu">
		<li id="menu-item-3939" class="menu-item menu-item-type-post_type menu-item-object-product menu-item-3939"><a href="https://www.telenor.com.pk/personal/telenor/offers/full-day-offer/">Full Day Offer</a></li>
		<li id="menu-item-3940" class="menu-item menu-item-type-post_type menu-item-object-product menu-item-3940"><a href="https://www.telenor.com.pk/personal/telenor/offers/haftawar-sahulat-offer/">Haftawar Sahulat Offer</a></li>
		<li id="menu-item-7575" class="menu-item menu-item-type-post_type menu-item-object-product menu-item-7575"><a href="https://www.telenor.com.pk/personal/telenor/offers/monthly-easy-card-800/">Easy Card</a></li>
	</ul>
</li>
	<li id="menu-item-3942" class="menu-item menu-item-type-taxonomy menu-item-object-product_cat current-product-ancestor current-menu-parent current-product-parent menu-item-has-children mega-menu-col menu-item-3942"><a href="https://www.telenor.com.pk/personal/telenor/offers/">Offers</a>
	<ul class="sub-menu">
		<li id="menu-item-3988" class="menu-item menu-item-type-taxonomy menu-item-object-product_cat menu-item-3988"><a href="https://www.telenor.com.pk/personal/telenor/offers/hybrid/">All Usage Offer</a></li>
		<li id="menu-item-3992" class="menu-item menu-item-type-taxonomy menu-item-object-product_cat menu-item-3992"><a href="https://www.telenor.com.pk/personal/telenor/offers/calls/">Call Offers</a></li>
		<li id="menu-item-3993" class="menu-item menu-item-type-taxonomy menu-item-object-product_cat menu-item-3993"><a href="https://www.telenor.com.pk/personal/internet-offers-personal/internet/">Internet Offers</a></li>
		<li id="menu-item-3994" class="menu-item menu-item-type-taxonomy menu-item-object-product_cat menu-item-3994"><a href="https://www.telenor.com.pk/personal/telenor/offers/sms/">SMS Offers</a></li>
		<li id="menu-item-3995" class="menu-item menu-item-type-taxonomy menu-item-object-product_cat menu-item-3995"><a href="https://www.telenor.com.pk/personal/telenor/international-offers/">International Offers</a></li>
	</ul>
</li>
	<li id="menu-item-69906" class="menu-item menu-item-type-taxonomy menu-item-object-product_cat menu-item-has-children mega-menu-col menu-item-69906"><a href="https://www.telenor.com.pk/personal/telenor/stay-home-offers/">Stay Home Offers</a>
	<ul class="sub-menu">
		<li id="menu-item-69909" class="menu-item menu-item-type-post_type menu-item-object-product menu-item-69909"><a href="https://www.telenor.com.pk/personal/internet-offers-personal/internet/weekly-6-to-6-offer/">Weekly 6 to 6 Offer</a></li>
		<li id="menu-item-69910" class="menu-item menu-item-type-post_type menu-item-object-product menu-item-69910"><a href="https://www.telenor.com.pk/personal/internet-offers-personal/internet/4g-late-night-offer/">4G Late Night Offer</a></li>
		<li id="menu-item-69908" class="menu-item menu-item-type-post_type menu-item-object-product menu-item-69908"><a href="https://www.telenor.com.pk/personal/telenor/offers/weekly-voice-offpeak-offer/">Weekly Voice Offpeak Offer</a></li>
		<li id="menu-item-69907" class="menu-item menu-item-type-post_type menu-item-object-product menu-item-69907"><a href="https://www.telenor.com.pk/personal/telenor/offers/weekly-easy-card/">Weekly Easy Card</a></li>
		<li id="menu-item-69911" class="menu-item menu-item-type-post_type menu-item-object-product menu-item-69911"><a href="https://www.telenor.com.pk/personal/telenor/offers/sahulat-mini-offer/">Sahulat Mini Offer</a></li>
	</ul>
</li>
</ul>

<ul class="sub-menu mega-menu-row">
	<li id="menu-item-4319" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children mega-menu-col menu-item-4319"><a href="https://www.telenor.com.pk/international/">International</a>
	<ul class="sub-menu">
		<li id="menu-item-6293" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-6293"><a href="https://www.telenor.com.pk/telenor-international-direct-dialing/">International Direct Dialing</a></li>
		<li id="menu-item-3952" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-3952"><a href="https://www.telenor.com.pk/international-roaming/">International Roaming</a></li>
		<li id="menu-item-5331" class="menu-item menu-item-type-taxonomy menu-item-object-product_cat menu-item-5331"><a href="https://www.telenor.com.pk/personal/telenor/international-offers/">International Direct Dialing Offers</a></li>
	</ul>
</li>
	<li id="menu-item-5443" class="menu-item menu-item-type-post_type menu-item-object-page mega-menu-col menu-item-5443"><a href="https://www.telenor.com.pk/my-telenor-app/">My Telenor App</a></li>
</ul>

<ul class="sub-menu mega-menu-row">
	<li id="menu-item-3956" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children mega-menu-col menu-item-3956"><a href="#">See Also</a>
	<ul class="sub-menu">
		<li id="menu-item-6628" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-6628"><a href="https://www.telenor.com.pk/my-offer/">My Offer</a></li>
		<li id="menu-item-3954" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-3954"><a href="https://www.telenor.com.pk/telenor-bundle-calculator/">Telenor Bundle Calculator</a></li>
	</ul>
</li>
</ul>
</div></li>
<li id="menu-item-3917" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children menu-item-has-mega-menu menu-item-3917"><a href="https://www.telenor.com.pk/internet-data/">Internet</a><div class="mega-menu">
<ul class="sub-menu mega-menu-row">
	<li id="menu-item-4381" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children mega-menu-col menu-item-4381"><a href="https://www.telenor.com.pk/internet-data/">Internet</a>
	<ul class="sub-menu">
		<li id="menu-item-4380" class="menu-item menu-item-type-post_type menu-item-object-product menu-item-4380"><a href="https://www.telenor.com.pk/personal/telenor/offers/4g-3-day-bundle/">3 Day Bundle</a></li>
		<li id="menu-item-4384" class="menu-item menu-item-type-post_type menu-item-object-product menu-item-4384"><a href="https://www.telenor.com.pk/personal/internet-offers-personal/internet/4g-monthly-starter-bundle/">Monthly Bundle</a></li>
		<li id="menu-item-4385" class="menu-item menu-item-type-post_type menu-item-object-product menu-item-4385"><a href="https://www.telenor.com.pk/bundles/monthly-starter/">Monthly Starter</a></li>
	</ul>
</li>
	<li id="menu-item-4386" class="menu-item menu-item-type-taxonomy menu-item-object-product_cat menu-item-has-children mega-menu-col menu-item-4386"><a href="https://www.telenor.com.pk/personal/internet-offers-personal/internet/">Top Internet Offers</a>
	<ul class="sub-menu">
		<li id="menu-item-11673" class="menu-item menu-item-type-post_type menu-item-object-product menu-item-11673"><a href="https://www.telenor.com.pk/personal/telenor/offers/internet-offers/monthly-social-pack/">Monthly Facebook &amp; WhatsApp Offer</a></li>
		<li id="menu-item-6296" class="menu-item menu-item-type-post_type menu-item-object-product menu-item-6296"><a href="https://www.telenor.com.pk/personal/telenor/offers/4g-weekly-ultra/">4G Weekly Ultra</a></li>
		<li id="menu-item-6301" class="menu-item menu-item-type-post_type menu-item-object-product menu-item-6301"><a href="https://www.telenor.com.pk/personal/4g-weekly-ultra-plus/">4G Weekly Ultra Plus</a></li>
		<li id="menu-item-6297" class="menu-item menu-item-type-post_type menu-item-object-product menu-item-6297"><a href="https://www.telenor.com.pk/bundles/monthly-starter/">Monthly Starter</a></li>
	</ul>
</li>
	<li id="menu-item-4551" class="menu-item menu-item-type-taxonomy menu-item-object-product_cat menu-item-has-children mega-menu-col menu-item-4551"><a href="https://www.telenor.com.pk/bundles/mbb-devices-bundles/">MBB Devices Bundles</a>
	<ul class="sub-menu">
		<li id="menu-item-4552" class="menu-item menu-item-type-post_type menu-item-object-product menu-item-4552"><a href="https://www.telenor.com.pk/bundles/4g-monthly-lite/">4G Monthly Lite</a></li>
		<li id="menu-item-4553" class="menu-item menu-item-type-post_type menu-item-object-product menu-item-4553"><a href="https://www.telenor.com.pk/bundles/4g-monthly-smart/">4G Monthly Smart</a></li>
		<li id="menu-item-4554" class="menu-item menu-item-type-post_type menu-item-object-product menu-item-4554"><a href="https://www.telenor.com.pk/bundles/4g-monthly-value/">4G Monthly Value</a></li>
		<li id="menu-item-4555" class="menu-item menu-item-type-post_type menu-item-object-product menu-item-4555"><a href="https://www.telenor.com.pk/bundles/4g-monthly-unlimited/">4G Monthly Unlimited</a></li>
		<li id="menu-item-4556" class="menu-item menu-item-type-post_type menu-item-object-product menu-item-4556"><a href="https://www.telenor.com.pk/bundles/4g-3-month-bundle/">4G 3 Month Bundle</a></li>
	</ul>
</li>
	<li id="menu-item-4557" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children mega-menu-col menu-item-4557"><a href="#">See Also</a>
	<ul class="sub-menu">
		<li id="menu-item-4558" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-4558"><a href="https://www.telenor.com.pk/4g-sim-check/">4G SIM Check</a></li>
		<li id="menu-item-4559" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-4559"><a href="https://www.telenor.com.pk/internet-settings/">Internet Settings</a></li>
		<li id="menu-item-4560" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-4560"><a href="https://www.telenor.com.pk/?page_id=1753">Coverage Map</a></li>
		<li id="menu-item-4561" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-4561"><a href="https://www.telenor.com.pk/4g-device-check/">4G Device Check</a></li>
		<li id="menu-item-26615" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-26615"><a href="https://www.telenor.com.pk/mobile-data-plan/">Mobile Data Plan</a></li>
	</ul>
</li>
	<li id="menu-item-4565" class="menu-item menu-item-type-taxonomy menu-item-object-product_cat mega-menu-col menu-item-4565"><a href="https://www.telenor.com.pk/personal/internet-offers-personal/sim-internet/">SIM Internet</a></li>
</ul>
</div></li>
<li id="menu-item-4349" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children menu-item-has-mega-menu menu-item-4349"><a href="https://www.telenor.com.pk/telenor-postpaid/">Postpaid</a><div class="mega-menu">
<ul class="sub-menu mega-menu-row">
	<li id="menu-item-6568" class="menu-item menu-item-type-post_type menu-item-object-page mega-menu-col menu-item-6568"><a href="https://www.telenor.com.pk/postpaid-conversion/">Switch to Postpaid</a></li>
	<li id="menu-item-4348" class="menu-item menu-item-type-taxonomy menu-item-object-product_cat menu-item-has-children mega-menu-col menu-item-4348"><a href="https://www.telenor.com.pk/price-plans/postpaid-price-plans/">Price Plans</a>
	<ul class="sub-menu">
		<li id="menu-item-4352" class="menu-item menu-item-type-taxonomy menu-item-object-product_cat menu-item-4352"><a href="https://www.telenor.com.pk/price-plans/postpaid-price-plans/freedom-plans/">Freedom Plans</a></li>
		<li id="menu-item-4351" class="menu-item menu-item-type-taxonomy menu-item-object-product_cat menu-item-4351"><a href="https://www.telenor.com.pk/price-plans/postpaid-price-plans/smart-plans/">Smart Plans</a></li>
	</ul>
</li>
	<li id="menu-item-6877" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children mega-menu-col menu-item-6877"><a href="#">Bundles</a>
	<ul class="sub-menu">
		<li id="menu-item-4356" class="menu-item menu-item-type-taxonomy menu-item-object-product_cat menu-item-4356"><a href="https://www.telenor.com.pk/post-paid/call-bundles/">Call Bundles</a></li>
		<li id="menu-item-101305" class="menu-item menu-item-type-taxonomy menu-item-object-product_cat menu-item-101305"><a href="https://www.telenor.com.pk/post-paid/hybrid-bundles/">Hybrid Bundles</a></li>
		<li id="menu-item-4358" class="menu-item menu-item-type-taxonomy menu-item-object-product_cat menu-item-4358"><a href="https://www.telenor.com.pk/post-paid/sms-bundles/">SMS Bundles</a></li>
		<li id="menu-item-4357" class="menu-item menu-item-type-taxonomy menu-item-object-product_cat menu-item-4357"><a href="https://www.telenor.com.pk/post-paid/internet-bundles/">Internet Bundles</a></li>
	</ul>
</li>
	<li id="menu-item-4359" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children mega-menu-col menu-item-4359"><a href="https://www.telenor.com.pk/telenor/get-postpaid-sim/">Get Postpaid SIM</a>
	<ul class="sub-menu">
		<li id="menu-item-3949" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-3949"><a href="https://www.telenor.com.pk/convert-to-telenor/">Convert To Telenor</a></li>
		<li id="menu-item-5794" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-5794"><a href="https://www.telenor.com.pk/telenor-postpaid/calculate-plan/">Price Plan Recommender</a></li>
		<li id="menu-item-5795" class="menu-item menu-item-type-taxonomy menu-item-object-product_cat menu-item-5795"><a href="https://www.telenor.com.pk/price-plans/postpaid-price-plans/freedom-plans/">Plan Conversion</a></li>
	</ul>
</li>
	<li id="menu-item-4362" class="menu-item menu-item-type-taxonomy menu-item-object-product_cat menu-item-has-children mega-menu-col menu-item-4362"><a href="https://www.telenor.com.pk/postpaid-offers/">International Offers</a>
	<ul class="sub-menu">
		<li id="menu-item-4364" class="menu-item menu-item-type-post_type menu-item-object-product menu-item-4364"><a href="https://www.telenor.com.pk/personal/telenor/offers/idd-middle-east-offer/">IDD Middle East Offer</a></li>
		<li id="menu-item-4366" class="menu-item menu-item-type-post_type menu-item-object-product menu-item-4366"><a href="https://www.telenor.com.pk/personal/telenor/offers/usa-canada-and-uk-offer-2/">USA, Canada and UK Offer</a></li>
	</ul>
</li>
	<li id="menu-item-4367" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children mega-menu-col menu-item-4367"><a href="https://www.telenor.com.pk/international/">International</a>
	<ul class="sub-menu">
		<li id="menu-item-6290" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-6290"><a href="https://www.telenor.com.pk/telenor-international-direct-dialing/">International Dialing</a></li>
		<li id="menu-item-4369" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-4369"><a href="https://www.telenor.com.pk/international-roaming/">International Roaming</a></li>
	</ul>
</li>
	<li id="menu-item-4378" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children mega-menu-col menu-item-4378"><a href="https://www.telenor.com.pk/telenor-postpaid/billing/">Billing</a>
	<ul class="sub-menu">
		<li id="menu-item-4376" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-4376"><a href="https://www.telenor.com.pk/telenor-postpaid/billing/bill-receiving-options/">Bill Receiving Options</a></li>
		<li id="menu-item-4377" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-4377"><a href="https://www.telenor.com.pk/telenor-postpaid/billing/bill-payment-options/">Bill Payment Options</a></li>
	</ul>
</li>
</ul>
</div></li>
<li id="menu-item-3922" class="menu-item menu-item-type-taxonomy menu-item-object-product_cat menu-item-has-children menu-item-has-mega-menu menu-item-3922"><a href="https://www.telenor.com.pk/devices/">Shop</a><div class="mega-menu">
<ul class="sub-menu mega-menu-row">
	<li id="menu-item-4422" class="menu-item menu-item-type-taxonomy menu-item-object-product_cat menu-item-has-children mega-menu-col menu-item-4422"><a href="https://www.telenor.com.pk/devices/4g-mobile-phones/">4G Mobile Phones</a>
	<ul class="sub-menu">
		<li id="menu-item-26276" class="menu-item menu-item-type-post_type menu-item-object-product menu-item-26276"><a href="https://www.telenor.com.pk/devices/infinity-i5/">Infinity i5</a></li>
		<li id="menu-item-26274" class="menu-item menu-item-type-post_type menu-item-object-product menu-item-26274"><a href="https://www.telenor.com.pk/devices/infinity-e5/">Infinity e5</a></li>
		<li id="menu-item-26275" class="menu-item menu-item-type-post_type menu-item-object-product menu-item-26275"><a href="https://www.telenor.com.pk/devices/infinity-e5-pro/">Infinity e5 Pro</a></li>
	</ul>
</li>
	<li id="menu-item-4426" class="menu-item menu-item-type-taxonomy menu-item-object-product_cat menu-item-has-children mega-menu-col menu-item-4426"><a href="https://www.telenor.com.pk/devices/mobile/">Mobile Phones</a>
	<ul class="sub-menu">
		<li id="menu-item-4430" class="menu-item menu-item-type-taxonomy menu-item-object-product_cat menu-item-4430"><a href="https://www.telenor.com.pk/devices/mobile/samsung/">Samsung</a></li>
		<li id="menu-item-4427" class="menu-item menu-item-type-taxonomy menu-item-object-product_cat menu-item-4427"><a href="https://www.telenor.com.pk/devices/mobile/motorola/">Motorola</a></li>
	</ul>
</li>
	<li id="menu-item-4434" class="menu-item menu-item-type-taxonomy menu-item-object-product_cat menu-item-has-children mega-menu-col menu-item-4434"><a href="https://www.telenor.com.pk/devices/mobile-broadband/">Mobile Broadband</a>
	<ul class="sub-menu">
		<li id="menu-item-4436" class="menu-item menu-item-type-post_type menu-item-object-product menu-item-4436"><a href="https://www.telenor.com.pk/devices/4g-wingle/">4G Wingle</a></li>
	</ul>
</li>
	<li id="menu-item-6260" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children mega-menu-col menu-item-6260"><a href="#">Partnership</a>
	<ul class="sub-menu">
		<li id="menu-item-6262" class="menu-item menu-item-type-post_type menu-item-object-product menu-item-6262"><a href="https://www.telenor.com.pk/devices/samsung-galaxy-s10/">Samsung Galaxy S10</a></li>
		<li id="menu-item-6261" class="menu-item menu-item-type-post_type menu-item-object-product menu-item-6261"><a href="https://www.telenor.com.pk/devices/samsung-galaxy-s10-128gb/">Samsung Galaxy S10+</a></li>
	</ul>
</li>
	<li id="menu-item-4439" class="menu-item menu-item-type-post_type menu-item-object-page mega-menu-col menu-item-4439"><a href="https://www.telenor.com.pk/4g-device-check/">4G Device Check</a></li>
</ul>
</div></li>
<li id="menu-item-4692" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children menu-item-has-mega-menu menu-item-4692"><a href="https://www.telenor.com.pk/digital-products/">Digital Products</a><div class="mega-menu">
<ul class="sub-menu mega-menu-row">
	<li id="menu-item-91185" class="menu-item menu-item-type-post_type menu-item-object-page mega-menu-col menu-item-91185"><a href="https://www.telenor.com.pk/telenor-gaming/">Telenor Gaming</a></li>
</ul>

<ul class="sub-menu mega-menu-row">
	<li id="menu-item-6550" class="menu-item menu-item-type-post_type menu-item-object-product mega-menu-col menu-item-6550"><a href="https://www.telenor.com.pk/digital-product/netflix/">NETFLIX</a></li>
	<li id="menu-item-44648" class="menu-item menu-item-type-post_type menu-item-object-product mega-menu-col menu-item-44648"><a href="https://www.telenor.com.pk/digital-product/starzplay/">Starzplay</a></li>
	<li id="menu-item-44492" class="menu-item menu-item-type-post_type menu-item-object-product mega-menu-col menu-item-44492"><a href="https://www.telenor.com.pk/digital-product/digital-insurance/">Digital Insurance</a></li>
	<li id="menu-item-69416" class="menu-item menu-item-type-post_type menu-item-object-page mega-menu-col menu-item-69416"><a href="https://www.telenor.com.pk/digital-products/khushaal-watan/">Khushaal Watan</a></li>
</ul>
</div></li>
<li id="menu-item-5206" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children menu-item-has-mega-menu menu-item-5206"><a href="https://www.telenor.com.pk/international/">International</a><div class="mega-menu">
<ul class="sub-menu mega-menu-row">
	<li id="menu-item-5208" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children mega-menu-col menu-item-5208"><a href="https://www.telenor.com.pk/international-roaming/">International Roaming</a>
	<ul class="sub-menu">
		<li id="menu-item-8327" class="menu-item menu-item-type-taxonomy menu-item-object-product_cat menu-item-8327"><a href="https://www.telenor.com.pk/personal/telenor/international-offers/international-roaming-offers/">IR Offers</a></li>
	</ul>
</li>
	<li id="menu-item-6292" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children mega-menu-col menu-item-6292"><a href="https://www.telenor.com.pk/telenor-international-direct-dialing/">International Dialing</a>
	<ul class="sub-menu">
		<li id="menu-item-8326" class="menu-item menu-item-type-taxonomy menu-item-object-product_cat menu-item-8326"><a href="https://www.telenor.com.pk/personal/telenor/international-offers/international-dialing-offers/">IDD Offers</a></li>
	</ul>
</li>
</ul>
</div></li>
</ul></div>

</div>
			</header>

			<header class="mobile-menu">
				<span class="hamburger">
	<img src="https://www.telenor.com.pk/view/themes/telenor/assets/images/hamburger.png" alt="menu">
</span>

<div class="logo">
	<a href="https://www.telenor.com.pk">
		<img src="https://www.telenor.com.pk/view/themes/telenor/assets/images/logo.png" alt="Logo" class="logo-img">
	</a>
</div>

<div class="admin-mobile-icon">

			<a href="https://www.telenor.com.pk/login">
			<img src="https://www.telenor.com.pk/view/themes/telenor/assets/images/admin-mobile-icon.png" alt="admin-mobile-icon">
		</a>
	</div>


<div class="shopping-cart">
	<a href="#" class="tp-m-cart-icon-header dropdown-toggle" id="dropdownMenuButtonCartNewMobile" data-toggle="dropdown" aria-expanded="true">
		
	   <span class="count cart-contents-count">
			0</span>
		

	   
	</a>

	<div class="dropdown-menu cart-dropdown" aria-labelledby="dropdownMenuButtonCart">
	<h5>Your cart has 0 item(s)</h5>
	<ul class="tp-header-mini-cart">
			<li class="dropdown-item clearfix">
			<span class="sub-total fLeft">Sub Total</span>
			<span class="total-price fRgight">Rs. 0</span>
		</li>
		<li class="dropdown-item clearfix dropdown-item-last">
			<a href="https://www.telenor.com.pk/devices/" class="cart_checkout">View Cart &amp; Checkout</a>
		</li>

	</ul>
  </div>

</div>

                <div class="mobile-block top-header-menu">
    <a href="#" class="icon-mobile-menu-close"></a>
    <div class="mobile-block-head">
        <div class="main-cat-nav">
            <ul><li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-home menu-item-5076 secondary-menu"><a href="https://www.telenor.com.pk/" class="active">Personal</a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-3722 business-menu"><a href="https://www.telenor.com.pk/business/">Business</a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-3723 my-account-menu"><a href="https://www.telenor.com.pk/login/">My Account</a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-4240 about-menu"><a href="https://www.telenor.com.pk/about/">About</a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-3916 help-and-support"><a href="https://www.telenor.com.pk/help-support/">Help &amp; Support</a></li>
</ul>        </div>

    <div class="mobile-block-body">
        <div class="nav-menu tp-secondary-header-menu-mobile">
            <ul id="menu" class="node-1"><li class="node-1-items has-children"><a href="#">Telenor</a><ul class="submenu node-2 "><li class="node-2-items has-children"><a href="#">Price Plans</a><ul class="submenu node-3 "><li class="node-3-items"><a href="https://www.telenor.com.pk/price-plans/telenor-economy/">Telenor Economy</a></li><li class="node-3-items"><a href="https://www.telenor.com.pk/price-plans/telenor-value/">Telenor Value</a></li><li class="node-3-items"><a href="https://www.telenor.com.pk/price-plans/telenor-a1/">Telenor A1</a></li></ul></li><li class="node-2-items has-children"><a href="#">Top Offers</a><ul class="submenu node-3 "><li class="node-3-items"><a href="https://www.telenor.com.pk/personal/telenor/offers/full-day-offer/">Full Day Offer</a></li><li class="node-3-items"><a href="https://www.telenor.com.pk/personal/telenor/offers/haftawar-sahulat-offer/">Haftawar Sahulat Offer</a></li><li class="node-3-items"><a href="https://www.telenor.com.pk/personal/telenor/offers/monthly-easy-card-800/">Easy Card</a></li></ul></li><li class="node-2-items has-children"><a href="#">Offers</a><ul class="submenu node-3 "><li class="node-3-items"><a href="https://www.telenor.com.pk/personal/telenor/offers/hybrid/">All Usage Offer</a></li><li class="node-3-items"><a href="https://www.telenor.com.pk/personal/telenor/offers/calls/">Call Offers</a></li><li class="node-3-items"><a href="https://www.telenor.com.pk/personal/internet-offers-personal/internet/">Internet Offers</a></li><li class="node-3-items"><a href="https://www.telenor.com.pk/personal/telenor/offers/sms/">SMS Offers</a></li><li class="node-3-items"><a href="https://www.telenor.com.pk/personal/telenor/international-offers/">International Offers</a></li></ul></li><li class="node-2-items has-children"><a href="#">Stay Home Offers</a><ul class="submenu node-3 "><li class="node-3-items"><a href="https://www.telenor.com.pk/personal/internet-offers-personal/internet/weekly-6-to-6-offer/">Weekly 6 to 6 Offer</a></li><li class="node-3-items"><a href="https://www.telenor.com.pk/personal/internet-offers-personal/internet/4g-late-night-offer/">4G Late Night Offer</a></li><li class="node-3-items"><a href="https://www.telenor.com.pk/personal/telenor/offers/weekly-voice-offpeak-offer/">Weekly Voice Offpeak Offer</a></li><li class="node-3-items"><a href="https://www.telenor.com.pk/personal/telenor/offers/weekly-easy-card/">Weekly Easy Card</a></li><li class="node-3-items"><a href="https://www.telenor.com.pk/personal/telenor/offers/sahulat-mini-offer/">Sahulat Mini Offer</a></li></ul></li><li class="node-2-items has-children"><a href="#">International</a><ul class="submenu node-3 "><li class="node-3-items"><a href="https://www.telenor.com.pk/telenor-international-direct-dialing/">International Direct Dialing</a></li><li class="node-3-items"><a href="https://www.telenor.com.pk/international-roaming/">International Roaming</a></li><li class="node-3-items"><a href="https://www.telenor.com.pk/personal/telenor/international-offers/">International Direct Dialing Offers</a></li></ul></li><li class="node-2-items"><a href="https://www.telenor.com.pk/my-telenor-app/">My Telenor App</a></li><li class="node-2-items has-children"><a href="#">See Also</a><ul class="submenu node-3 "><li class="node-3-items"><a href="https://www.telenor.com.pk/my-offer/">My Offer</a></li><li class="node-3-items"><a href="https://www.telenor.com.pk/telenor-bundle-calculator/">Telenor Bundle Calculator</a></li></ul></li></ul></li><li class="node-1-items has-children"><a href="#">Internet</a><ul class="submenu node-2 "><li class="node-2-items has-children"><a href="#">Internet</a><ul class="submenu node-3 "><li class="node-3-items"><a href="https://www.telenor.com.pk/personal/telenor/offers/4g-3-day-bundle/">3 Day Bundle</a></li><li class="node-3-items"><a href="https://www.telenor.com.pk/personal/internet-offers-personal/internet/4g-monthly-starter-bundle/">Monthly Bundle</a></li><li class="node-3-items"><a href="https://www.telenor.com.pk/bundles/monthly-starter/">Monthly Starter</a></li></ul></li><li class="node-2-items has-children"><a href="#">Top Internet Offers</a><ul class="submenu node-3 "><li class="node-3-items"><a href="https://www.telenor.com.pk/personal/telenor/offers/internet-offers/monthly-social-pack/">Monthly Facebook &amp; WhatsApp Offer</a></li><li class="node-3-items"><a href="https://www.telenor.com.pk/personal/telenor/offers/4g-weekly-ultra/">4G Weekly Ultra</a></li><li class="node-3-items"><a href="https://www.telenor.com.pk/personal/4g-weekly-ultra-plus/">4G Weekly Ultra Plus</a></li><li class="node-3-items"><a href="https://www.telenor.com.pk/bundles/monthly-starter/">Monthly Starter</a></li></ul></li><li class="node-2-items has-children"><a href="#">MBB Devices Bundles</a><ul class="submenu node-3 "><li class="node-3-items"><a href="https://www.telenor.com.pk/bundles/4g-monthly-lite/">4G Monthly Lite</a></li><li class="node-3-items"><a href="https://www.telenor.com.pk/bundles/4g-monthly-smart/">4G Monthly Smart</a></li><li class="node-3-items"><a href="https://www.telenor.com.pk/bundles/4g-monthly-value/">4G Monthly Value</a></li><li class="node-3-items"><a href="https://www.telenor.com.pk/bundles/4g-monthly-unlimited/">4G Monthly Unlimited</a></li><li class="node-3-items"><a href="https://www.telenor.com.pk/bundles/4g-3-month-bundle/">4G 3 Month Bundle</a></li></ul></li><li class="node-2-items has-children"><a href="#">See Also</a><ul class="submenu node-3 "><li class="node-3-items"><a href="https://www.telenor.com.pk/4g-sim-check/">4G SIM Check</a></li><li class="node-3-items"><a href="https://www.telenor.com.pk/internet-settings/">Internet Settings</a></li><li class="node-3-items"><a href="https://www.telenor.com.pk/?page_id=1753">Coverage Map</a></li><li class="node-3-items"><a href="https://www.telenor.com.pk/4g-device-check/">4G Device Check</a></li><li class="node-3-items"><a href="https://www.telenor.com.pk/mobile-data-plan/">Mobile Data Plan</a></li></ul></li><li class="node-2-items"><a href="https://www.telenor.com.pk/personal/internet-offers-personal/sim-internet/">SIM Internet</a></li></ul></li><li class="node-1-items has-children"><a href="#">Postpaid</a><ul class="submenu node-2 "><li class="node-2-items"><a href="https://www.telenor.com.pk/postpaid-conversion/">Switch to Postpaid</a></li><li class="node-2-items has-children"><a href="#">Price Plans</a><ul class="submenu node-3 "><li class="node-3-items"><a href="https://www.telenor.com.pk/price-plans/postpaid-price-plans/freedom-plans/">Freedom Plans</a></li><li class="node-3-items"><a href="https://www.telenor.com.pk/price-plans/postpaid-price-plans/smart-plans/">Smart Plans</a></li></ul></li><li class="node-2-items has-children"><a href="#">Bundles</a><ul class="submenu node-3 "><li class="node-3-items"><a href="https://www.telenor.com.pk/post-paid/call-bundles/">Call Bundles</a></li><li class="node-3-items"><a href="https://www.telenor.com.pk/post-paid/hybrid-bundles/">Hybrid Bundles</a></li><li class="node-3-items"><a href="https://www.telenor.com.pk/post-paid/sms-bundles/">SMS Bundles</a></li><li class="node-3-items"><a href="https://www.telenor.com.pk/post-paid/internet-bundles/">Internet Bundles</a></li></ul></li><li class="node-2-items has-children"><a href="#">Get Postpaid SIM</a><ul class="submenu node-3 "><li class="node-3-items"><a href="https://www.telenor.com.pk/convert-to-telenor/">Convert To Telenor</a></li><li class="node-3-items"><a href="https://www.telenor.com.pk/telenor-postpaid/calculate-plan/">Price Plan Recommender</a></li><li class="node-3-items"><a href="https://www.telenor.com.pk/price-plans/postpaid-price-plans/freedom-plans/">Plan Conversion</a></li></ul></li><li class="node-2-items has-children"><a href="#">International Offers</a><ul class="submenu node-3 "><li class="node-3-items"><a href="https://www.telenor.com.pk/personal/telenor/offers/idd-middle-east-offer/">IDD Middle East Offer</a></li><li class="node-3-items"><a href="https://www.telenor.com.pk/personal/telenor/offers/usa-canada-and-uk-offer-2/">USA, Canada and UK Offer</a></li></ul></li><li class="node-2-items has-children"><a href="#">International</a><ul class="submenu node-3 "><li class="node-3-items"><a href="https://www.telenor.com.pk/telenor-international-direct-dialing/">International Dialing</a></li><li class="node-3-items"><a href="https://www.telenor.com.pk/international-roaming/">International Roaming</a></li></ul></li><li class="node-2-items has-children"><a href="#">Billing</a><ul class="submenu node-3 "><li class="node-3-items"><a href="https://www.telenor.com.pk/telenor-postpaid/billing/bill-receiving-options/">Bill Receiving Options</a></li><li class="node-3-items"><a href="https://www.telenor.com.pk/telenor-postpaid/billing/bill-payment-options/">Bill Payment Options</a></li></ul></li></ul></li><li class="node-1-items has-children"><a href="#">Shop</a><ul class="submenu node-2 "><li class="node-2-items has-children"><a href="#">4G Mobile Phones</a><ul class="submenu node-3 "><li class="node-3-items"><a href="https://www.telenor.com.pk/devices/infinity-i5/">Infinity i5</a></li><li class="node-3-items"><a href="https://www.telenor.com.pk/devices/infinity-e5/">Infinity e5</a></li><li class="node-3-items"><a href="https://www.telenor.com.pk/devices/infinity-e5-pro/">Infinity e5 Pro</a></li></ul></li><li class="node-2-items has-children"><a href="#">Mobile Phones</a><ul class="submenu node-3 "><li class="node-3-items"><a href="https://www.telenor.com.pk/devices/mobile/samsung/">Samsung</a></li><li class="node-3-items"><a href="https://www.telenor.com.pk/devices/mobile/motorola/">Motorola</a></li></ul></li><li class="node-2-items has-children"><a href="#">Mobile Broadband</a><ul class="submenu node-3 "><li class="node-3-items"><a href="https://www.telenor.com.pk/devices/4g-wingle/">4G Wingle</a></li></ul></li><li class="node-2-items has-children"><a href="#">Partnership</a><ul class="submenu node-3 "><li class="node-3-items"><a href="https://www.telenor.com.pk/devices/samsung-galaxy-s10/">Samsung Galaxy S10</a></li><li class="node-3-items"><a href="https://www.telenor.com.pk/devices/samsung-galaxy-s10-128gb/">Samsung Galaxy S10+</a></li></ul></li><li class="node-2-items"><a href="https://www.telenor.com.pk/4g-device-check/">4G Device Check</a></li></ul></li><li class="node-1-items has-children"><a href="#">Digital Products</a><ul class="submenu node-2 "><li class="node-2-items"><a href="https://www.telenor.com.pk/telenor-gaming/">Telenor Gaming</a></li><li class="node-2-items"><a href="https://www.telenor.com.pk/digital-product/netflix/">NETFLIX</a></li><li class="node-2-items"><a href="https://www.telenor.com.pk/digital-product/starzplay/">Starzplay</a></li><li class="node-2-items"><a href="https://www.telenor.com.pk/digital-product/digital-insurance/">Digital Insurance</a></li><li class="node-2-items"><a href="https://www.telenor.com.pk/digital-products/khushaal-watan/">Khushaal Watan</a></li></ul></li><li class="node-1-items has-children"><a href="#">International</a><ul class="submenu node-2 "><li class="node-2-items has-children"><a href="#">International Roaming</a><ul class="submenu node-3 "><li class="node-3-items"><a href="https://www.telenor.com.pk/personal/telenor/international-offers/international-roaming-offers/">IR Offers</a></li></ul></li><li class="node-2-items has-children"><a href="#">International Dialing</a><ul class="submenu node-3 "><li class="node-3-items"><a href="https://www.telenor.com.pk/personal/telenor/international-offers/international-dialing-offers/">IDD Offers</a></li></ul></li></ul></li></ul>        </div>
    </div>
</div>			</header>
		
		
		

		
		<div class="tp-mobile-sub-header-container">
					</div>

	

	
		<!-- Shop Products Loop -->
		<div class="tp_devices_container">

      				    <div class="tp_breadcrum_container">
		    	<div class="tp-container container-fluid">
		    		<div class="row">
		    			<div class="col-sm-12">
		    				<p class="breadcrumLinks">
		    					<span class="posted_in"> <a href="https://www.telenor.com.pk/personal/telenor/offers/internet-offers/" rel="tag">Internet Offers</a><a href="https://www.telenor.com.pk/personal/telenor/offers/" rel="tag">Offers</a><a href="https://www.telenor.com.pk/personal/telenor/prepaid-offers/" rel="tag">Prepaid</a><a href="https://www.telenor.com.pk/personal/telenor/prepaid-offers/telenor-prepaid-offers/" rel="tag">Telenor</a><a href="https://www.telenor.com.pk/personal/telenor/offers/top-offers/" rel="tag">Top Offers</a></span>		    					<span>Free WhatsApp Offer</span>
	    					</p>
		    			</div>
		    		</div>
		    	</div>
		    </div>
	    
			<div class="tp-container container-fluid">
								<div class="row">
					
					
	
		
			<div class="woocommerce-notices-wrapper"></div>
<div id="product-2534" class="single-tp-offer">

<div class="tp_deviceDetails">
	<div class="tp-container container-fluid">
		<div class="row">
			<div class="col-sm-12">
				<div class="deviceDetails_cont">
					<div class="row">
												<div class="col-sm-8 tp-banner-image" style="background-image: url('https://www.telenor.com.pk/static/2018/12/Monthly-WhatsApp-Landing-Page-780x425-1.jpg');">
							
						</div>
						<div class="col-sm-4">
							<div class="deviceDetailsInfo single-product-attr ui-front">
								<div class="contentTitle">
									<h1 class="product_title entry-title">Free WhatsApp Offer</h1>	<p class="price"></p><h2><span>Free </span></h2><p></p>
<div class="rel_text top-offer-desc">
	<p>Message, send photos and share videos on WhatsApp all you want!</p>
<p>*Rs. 0.01 will be charged upon subscription of this offer</p>
</div>
<strong class="icon tp-attr-icon attr-icon-21"><i style="background-image: url(https://www.telenor.com.pk/static/2018/12/icn_0006_internet-1.png)"></i>Internet</strong> 1500 MB<br><strong class="icon tp-attr-icon attr-icon-29"><i style="background-image: url(https://www.telenor.com.pk/static/2018/12/validity.png)"></i>Validity</strong> 30 Days<br><strong class="icon tp-attr-icon attr-icon-19"><i style="background-image: url(https://www.telenor.com.pk/static/2018/12/offnet_icon.png)"></i>Dial</strong> *247#<br><div class="mobileField">
	<label>Confirm Mobile Number</label>
	<input type="text" maxlength="11" class="msisdn" placeholder="03451234567" pattern="[0-9]*" onfocus="this.placeholder = ''" onblur="this.placeholder = '03451234567'" value="">
	<input type="hidden" class="price" value="0">
	<input type="hidden" class="tname" name="tName" value="">
		<input type="hidden" class="tp-offer-product-id" name="tp_offer_product_id" value="4d69db74badbc7a7387f08f039d1db1582534">
			<input type="hidden" name="action" class="tp-activation-action" onclick="document.getElementById('modal-wrapper').style.display='block'" value="activate_offers">
	</div>
<div class="activateBtn_block">
	<button class="activateBtn btn tp-activate-btn" onclick="document.getElementById('modal-wrapper').style.display='block'" id="tp-no-campaign-product-single">Activate</button>
</div>
<!--Message Modal Start-->
<div id="MessageModal" class="modal fade tp-activate-modals" role="dialog">
	<div class="modal-dialog">
		<!-- Modal content-->
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal">×</button>
				<h4 class="modal-title">Error</h4>
				<div class="msg-body">Something went wrong</div>
				<a id="continueshop" class="tp-continue-shopping" href="#">Continue Shopping</a>
			</div>
		</div>
	</div>
</div>



<!--Message Modal End-->
									<!-- <div class="deviceRating"></div> -->
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>

<div class="tp-ajax-loader"><img src="https://www.telenor.com.pk/view/themes/telenor/assets/images/ajax-loader-white-bg.gif"></div>






	<div class="deviceDetailTabs tp-tabs--full-width">
		<div class="tp-container container-fluid">
			<div class="row">
				<div class="col-xs-12">
					<ul class="nav nav-tabs">
													<li class="active">
								<a data-toggle="tab" href="#description">
									Overview								</a>
							</li>
													<li class="">
								<a data-toggle="tab" href="#faqs">
									FAQs								</a>
							</li>
													<li class="">
								<a data-toggle="tab" href="#additional_information">
																	</a>
							</li>
											</ul>
				</div>
			</div>
		</div>
	</div>

	<div class="deviceDetailContents">
		<div class="tp-container container-fluid">
			<div class="row">
				<div class="col-xs-12">
					<div class="tab-content devSpecFaq">
													<div id="description" class="tab-pane fade in active">
								<div class="">
									

<p>Enjoy unlimited messaging, photo and video sharing on WhatsApp with Telenor for free!</p>
<h3>Offer Eligibility</h3>
<p>All Telenor prepaid users are eligible for this offer.</p>
<p>Customers who don’t have internet settings activated can SMS ‘internet’ to 131 to get internet settings for their device.</p>
<h3>Validity:</h3>
<p>Package is valid for 30 days and subscribers will be informed when package expires at midnight.</p>
<p>Rs. 0.01 will be charged upon subscription of this offer.</p>
<p>Rs. 5 incl. tax will be charged on subscription in Astore, Diamer, Ghanche, Ghizer, Hunza-Nagar, Skardu, Gilgit, Bagh, Bhimber, Poonch, Hattian, Sudhnati, Muzaffarabad, Mirpur, Kotli, Abbotabad, Batgram, Chitral, Haripur, Kohistan, Lower Dir, Malakand, Mansehra, Shangla, Swat and Upper Dir.</p>
<p>&nbsp;</p>
								</div>
							</div>
													<div id="faqs" class="tab-pane fade in ">
								<div class="">
									<section class="faqs-container faq-tab accordion-section clearfix mt-3">
  <div class="container">
	  <div class="panel-group">
            		<div class="panel panel-default">
		  <div class="panel-heading tab-head p-3 mb-3" id="heading0">
			<h3 class="panel-title">
			  <a href="javascript:void(null)" aria-expanded="true" aria-controls="collapse0">
				What will happen if user purchases any Internet Bundle with this offer?			  </a>
			</h3>
		  </div>
		  <div id="collapse-1097" class="panel-collapse tab-details">
			<div class="panel-body px-3 mb-4">
			  <div class="user_content_demo">
<div class="text_box">

Bundle will be activated. Each bundle will expire as per its own validity. Bundle with lower validity will be consumed first.

</div>
</div>
<div class="user_content_demo">
<div class="text_box">
<div class="text_head"></div>
</div>
</div>			</div>
		  </div>
		</div>
      		<div class="panel panel-default">
		  <div class="panel-heading tab-head p-3 mb-3" id="heading0">
			<h3 class="panel-title">
			  <a href="javascript:void(null)" aria-expanded="true" aria-controls="collapse0">
				Is this offer mutually exclusive with any other offer?			  </a>
			</h3>
		  </div>
		  <div id="collapse-1095" class="panel-collapse tab-details">
			<div class="panel-body px-3 mb-4">
			  <div class="user_content_demo">
<div class="text_box">

No, this offer is not mutually exclusive with any other offer.

</div>
</div>
<div class="user_content_demo">
<div class="text_box">
<div class="text_head"></div>
</div>
</div>			</div>
		  </div>
		</div>
                </div>
  </div>
</section>
								</div>
							</div>
													<div id="additional_information" class="tab-pane fade in ">
								<div class="">
																	</div>
							</div>
											</div>
				</div>
			</div>
		</div>
	</div>

<div class="deviceDetailContents">
	<div class="tp-container container-fluid">
		<div class="row">
			<div class="col-xs-12">
				<div class="deviceReviews_wrapper tp-terms-conditions-container">
											<h2 class="tp-terms-conditions-heading">Terms and Conditions</h2>
					
					<ul>
<li>If subscribers change their package, the WhatsApp bundle will expire and will have to be activated again</li>
</ul>
<ul>
<li>Rates and/or resources may vary based on geographical location.</li>
</ul>
<ul>
<li>Subscribers will be charged only if they share their location from WhatsApp. Other than that all WhatsApp usage is free</li>
</ul>
<ul>
<li>Subscribers will not be able to avail Free WhatsApp if they have Zero balance as an internet session cannot be initiated in 0 balance state. Even if the customer has 1 Paisa in their account they can avail the Free WhatsApp Offer</li>
</ul>
				</div>
			</div>
		</div>
	</div>
</div>

	
<div class="deviceDetailReviews ">
	<div class="tp-container container-fluid">
		<div class="row">
			<div class="col-xs-12">
				<div class="deviceReviews_wrapper">
					<h2>
						Recommended Offers					</h2>

					<ul class="products columns-3">

						
							

<div class="isotope-item col-sm-4 post-398 product type-product status-publish has-post-thumbnail product_cat-offers product_cat-prepaid-offers product_cat-sms product_cat-sms-offers product_cat-telenor-prepaid-offers product_cat-top-offers first instock shipping-taxable purchasable product-type-simple">

	
		<div class="offerBlock orangeTop">
			
			<div class="innerOfferBlock">
				<div class="offerBlockHeader">
					<img src="https://www.telenor.com.pk/static/2018/12/Telenor.png" class="offerImage wp-post-image" alt="">
					<h3>
						<a href="https://www.telenor.com.pk/personal/telenor/offers/weekly-sms-bundle/">
							Weekly SMS Bundle						</a>
					</h3>
				</div>

				<div class="offerDetails">
						<span class="grey_color font12 js-tp-product-price">Free </span>
<span class="grey_color font12">SMS: 1200</span><span class="grey_color font12">Validity: 7 Days</span>				</div>
			</div>

			<div class="innerOfferBlock">
	<div class="confirmMobile_block">
		<div class="mobileField">
			<input type="text" class="msisdn" maxlength="11" placeholder="Number" pattern="[0-9]*" onfocus="this.placeholder = ''" onblur="this.placeholder = 'Number'" value="">
			<input type="hidden" class="offer-name" name="offerName" value="Free WhatsApp Offer">
							<input type="hidden" name="action" class="tp-activation-action" value="activate_offers">
						<input type="hidden" class="price" value="0">
						<input type="hidden" class="tname" name="tName" value="">
			<input type="hidden" class="tp-offer-product-id" name="tp_offer_product_id" value="4d69db74badbc7a7387f08f039d1db1582534">
		</div>
	</div>
	<div class="offerActivation_block">
		<div class="activateBtn_block">
			<button class="offer_activate activateBtn btn tp-activate-btn" onclick="document.getElementById('modal-wrapper').style.display='block'">Activate</button>
		</div>
	</div>
</div>
		</div>

	</div>

<div class="tp-ajax-loader"><img src="https://www.telenor.com.pk/view/themes/telenor/assets/images/ajax-loader-white-bg.gif"></div>

						
							

<div class="isotope-item col-sm-4 post-1626 product type-product status-publish has-post-thumbnail product_cat-offers product_cat-prepaid-offers product_cat-sms product_cat-sms-offers product_cat-telenor-prepaid-offers product_cat-top-offers  instock shipping-taxable purchasable product-type-simple">

	
		<div class="offerBlock orangeTop">
			
			<div class="innerOfferBlock">
				<div class="offerBlockHeader">
					<img src="https://www.telenor.com.pk/static/2018/12/Telenor.png" class="offerImage wp-post-image" alt="">
					<h3>
						<a href="https://www.telenor.com.pk/personal/telenor/offers/15-day-economy-sms-bundle/">
							15 Day Economy SMS Bundle						</a>
					</h3>
				</div>

				<div class="offerDetails">
						<span class="grey_color font12 js-tp-product-price">Free </span>
<span class="grey_color font12">Validity: 15 Days</span><span class="grey_color font12">SMS: 800</span>				</div>
			</div>

			<div class="innerOfferBlock">
	<div class="confirmMobile_block">
		<div class="mobileField">
			<input type="text" class="msisdn" maxlength="11" placeholder="Number" pattern="[0-9]*" onfocus="this.placeholder = ''" onblur="this.placeholder = 'Number'" value="">
			<input type="hidden" class="offer-name" name="offerName" value="Free WhatsApp Offer">
							<input type="hidden" name="action" class="tp-activation-action" value="activate_offers">
						<input type="hidden" class="price" value="0">
						<input type="hidden" class="tname" name="tName" value="">
			<input type="hidden" class="tp-offer-product-id" name="tp_offer_product_id" value="4d69db74badbc7a7387f08f039d1db1582534">
		</div>
	</div>
	<div class="offerActivation_block">
		<div class="activateBtn_block">
			<button class="offer_activate activateBtn btn tp-activate-btn" onclick="document.getElementById('modal-wrapper').style.display='block'">Activate</button>
		</div>
	</div>
</div>
		</div>

	</div>

<div class="tp-ajax-loader"><img src="https://www.telenor.com.pk/view/themes/telenor/assets/images/ajax-loader-white-bg.gif"></div>

						
							

<div class="isotope-item col-sm-4 post-402 product type-product status-publish has-post-thumbnail product_cat-offers product_cat-prepaid-offers product_cat-sms product_cat-sms-offers product_cat-telenor-prepaid-offers last instock shipping-taxable purchasable product-type-simple">

	
		<div class="offerBlock orangeTop">
			
			<div class="innerOfferBlock">
				<div class="offerBlockHeader">
					<img src="https://www.telenor.com.pk/static/2018/12/Telenor.png" class="offerImage wp-post-image" alt="">
					<h3>
						<a href="https://www.telenor.com.pk/personal/telenor/offers/monthly-sms-bundle/">
							Monthly SMS Bundle						</a>
					</h3>
				</div>

				<div class="offerDetails">
						<span class="grey_color font12 js-tp-product-price">Free </span>
<span class="grey_color font12">Validity: 30 Days</span><span class="grey_color font12">SMS: 6000</span>				</div>
			</div>

			<div class="innerOfferBlock">
	<div class="confirmMobile_block">
		<div class="mobileField">
			<input type="text" class="msisdn" maxlength="11" placeholder="Number" pattern="[0-9]*" onfocus="this.placeholder = ''" onblur="this.placeholder = 'Number'" value="">
			<input type="hidden" class="offer-name" name="offerName" value="Free WhatsApp Offer">
							<input type="hidden" name="action" class="tp-activation-action" value="activate_offers">
						<input type="hidden" class="price" value="0">
						<input type="hidden" class="tname" name="tName" value="">
			<input type="hidden" class="tp-offer-product-id" name="tp_offer_product_id" value="4d69db74badbc7a7387f08f039d1db1582534">
		</div>
	</div>
	<div class="offerActivation_block">
		<div class="activateBtn_block">
			<button class="offer_activate activateBtn btn tp-activate-btn" onclick="document.getElementById('modal-wrapper').style.display='block'">Activate</button>
		</div>
	</div>
</div>
		</div>

	</div>

<div class="tp-ajax-loader"><img src="https://www.telenor.com.pk/view/themes/telenor/assets/images/ajax-loader-white-bg.gif"></div>

						
					</ul>

				</div>
			</div>
		</div>
	</div>
</div>










</div> <!-- /end-product -->

		
	
							</div>
						</div>
					</div>
									
			
		
	




		<footer id="footer" class="clearfix">
			<div class="widgets_wrapper">

				<a href="#" class="back-to-top">Back to Top</a>
				<a class="customer-care">Telenor Customer Care</a>

				<div class="container">
					<div class="customer-care-popup hide">
						<a href="#" id="popup-header">
							Telenor Customer Care
						</a>
						<div id="chat-contents-inner"></div>
					</div>

											<div class="column one-fourth">
							<aside id="nav_menu-2" class="widget widget_nav_menu"><h4>About</h4><ul id="menu-footer-section-one" class="menu"><li id="menu-item-4573" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-4573"><a href="https://www.telenor.com.pk/careers/">Careers</a></li>
<li id="menu-item-4574" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-4574"><a href="https://www.telenor.com.pk/about/sustainability/corporate-sustainability/">Corporate Sustainability</a></li>
<li id="menu-item-4575" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-4575"><a href="https://www.telenor.com.pk/media-center/">Media Center</a></li>
<li id="menu-item-4141" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-4141"><a href="https://www.telenor.com.pk/about/news-and-event/">News and Events</a></li>
</ul></aside>						</div>
					
											<div class="column one-fourth">
							<aside id="nav_menu-3" class="widget widget_nav_menu"><h4>Quick Links</h4><ul id="menu-footer-section-two" class="menu"><li id="menu-item-5522" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-home menu-item-5522"><a href="https://www.telenor.com.pk/">Telenor</a></li>
<li id="menu-item-3731" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-3731"><a href="https://www.telenor.com.pk/telenor-postpaid/">Postpaid</a></li>
<li id="menu-item-3725" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-3725"><a href="https://www.telenor.com.pk/business/">Business</a></li>
<li id="menu-item-3739" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-3739"><a href="https://www.telenor.com.pk/internet-data/">Internet</a></li>
<li id="menu-item-3733" class="menu-item menu-item-type-taxonomy menu-item-object-product_cat menu-item-3733"><a href="https://www.telenor.com.pk/value-added-services/">Value Added Services</a></li>
<li id="menu-item-3734" class="menu-item menu-item-type-taxonomy menu-item-object-product_cat menu-item-3734"><a href="https://www.telenor.com.pk/devices/">Devices</a></li>
</ul></aside>						</div>
					
											<div class="column one-fourth">
							<aside id="nav_menu-4" class="widget widget_nav_menu"><h4>Help and Support</h4><ul id="menu-footer-section-three" class="menu"><li id="menu-item-2666" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2666"><a href="https://www.telenor.com.pk/tutorials/">Tutorials</a></li>
<li id="menu-item-2663" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2663"><a href="https://www.telenor.com.pk/telenor/bundle-calculator/">Bundle Calculator</a></li>
<li id="menu-item-2665" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2665"><a href="https://www.telenor.com.pk/contact-us/">Contact Us</a></li>
</ul></aside>						</div>
					
					<div class="column one-fourth">
													<img src="https://www.telenor.com.pk/view/themes/telenor/assets/images/footer-icon.png" class="footer-logo">
							<a href="https://www.telenor.com.pk/login" class="signin-container">
								<img src="https://www.telenor.com.pk/view/themes/telenor/assets/images/signin-icon.png">
								<span>Sign in</span>
							</a>
																			<aside id="nav_menu-6" class="widget widget_nav_menu"><ul id="menu-franchise-portal-menu" class="menu"><li id="menu-item-6428" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-6428"><a href="https://www.telenor.com.pk/business-partner-portal/">Business Partner Portal</a></li>
<li id="menu-item-5648" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-5648"><a href="https://www.telenor.com.pk/franchise-portal/">Franchise Portal</a></li>
<li id="menu-item-100445" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-100445"><a href="https://www.telenor.com.pk/digital-channel-partnerships/">Digital Channel Partnerships</a></li>
</ul></aside>											</div>
				</div>
			</div>

			<div class="footer_copy">
				<div class="container">
					<div class="row">
						<div class="col-md-6 col-xs-12 col-sm-12 col-lg-6">
							<img src="https://www.telenor.com.pk/view/themes/telenor/assets/images/telenor4g-logo-footer.png">
						</div>
						<div class="col-md-6 col-xs-12 col-sm-12 col-lg-6 tar icon-social">
							<a href="https://www.instagram.com/telenor.pk/" target="_blank">
								<img src="https://www.telenor.com.pk/view/themes/telenor/assets/images/icon-insta.png">
							</a>
							<a href="https://twitter.com/telenorpakistan" target="_blank">
								<img src="https://www.telenor.com.pk/view/themes/telenor/assets/images/icon-twitter.png">
							</a>
							<a href="https://www.facebook.com/TelenorPk" target="_blank">
								<img src="https://www.telenor.com.pk/view/themes/telenor/assets/images/icon-facebook.png">
							</a>
						</div>
					</div>

					<div class="column one">
						<div class="copyright">
							2020 Telenor Pakistan
						</div>
						<div class="footer-custom-menu">
							<ul id="menu-footer-copyright-menu" class="menu">
																	<aside id="nav_menu-5" class="widget widget_nav_menu"><ul id="menu-footer-bottom-right-links-menu" class="menu"><li id="menu-item-5597" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-5597"><a href="https://www.telenor.com.pk/sitemap/">Sitemap</a></li>
<li id="menu-item-5593" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-5593"><a href="https://www.telenor.com.pk/terms-conditions/">Terms and Conditions</a></li>
<li id="menu-item-5594" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-privacy-policy menu-item-5594"><a href="https://www.telenor.com.pk/privacy-notice/">Privacy Notice</a></li>
</ul></aside>															</ul>
						</div>
					</div>
				</div>
			</div>
		</footer>
	
	<div class="tp-gsm-activation-res tp-hide"></div>
	<div class="tp-generic-message-popup-cont tp-hide"></div>
	<div id="loading_screen" style="display: none">
    <div class="shadow-bg"></div>
<style>
 .email-popup {
    left: 26%;
    margin: auto;
    position: fixed;
    top: 26%;
    width: auto;
    z-index: 1000000000;
}
					.email-popup-wrapper{ margin:auto; width:600px; /*box-shadow:0 10px 10px rgba(0,0,0,0.5); border-radius:8px; background:#eaeaea;*/ padding-bottom:5px;}
					.email-popup-heading{ /*background:url(images/email-popup-header.png) repeat-x; border-radius:8px 8px 0px 0px; padding-top:2px;
					color: #fff; font-size: 31px; letter-spacing:-0.5px; font-weight: lighter; text-shadow:0px -1px 1px #0d0c16; text-align:center;*/}
					.email-popup-heading span{ position:relative; top:-18px; }
					
					.email-popup-content{ /*background:#fff; border-radius:2px;*/ margin:100px; padding:10px; /*border:1px solid #cacaca;*/}
					.email-tittle{ font-size:15px; color:#000000; font-weight:bold;  line-height:34px;}
					.email-address{ border:1px solid #959496; padding:7px 10px 7px 10px; min-width:360px; border-radius:10px; box-shadow:0px 1px 0px #fff; font-size:15px; color:#000000; font-weight:bold;background:#fff;}
					.email-childs{ border:1px solid #959496; padding:6px 10px 3px 10px; min-width:104px; border-radius:10px; box-shadow:0px 1px 0px #fff; font-size:15px; color:#000000; font-weight:bold; 
					background: #f5f7f5; /* Old browsers */
					background: -moz-linear-gradient(top,  #f5f7f5 30%, #f5f7f5 30%, #d6d6d8 100%); /* FF3.6+ */
					background: -webkit-gradient(linear, left top, left bottom, color-stop(30%,#f5f7f5), color-stop(30%,#f5f7f5), color-stop(100%,#d6d6d8)); /* Chrome,Safari4+ */
					background: -webkit-linear-gradient(top,  #f5f7f5 30%,#f5f7f5 30%,#d6d6d8 100%); /* Chrome10+,Safari5.1+ */
					background: -o-linear-gradient(top,  #f5f7f5 30%,#f5f7f5 30%,#d6d6d8 100%); /* Opera 11.10+ */
					background: -ms-linear-gradient(top,  #f5f7f5 30%,#f5f7f5 30%,#d6d6d8 100%); /* IE10+ */
					background: linear-gradient(to bottom,  #f5f7f5 30%,#f5f7f5 30%,#d6d6d8 100%); /* W3C */
					filter: progid:DXImageTransform.Microsoft.gradient( startColorstr='#f5f7f5', endColorstr='#d6d6d8',GradientType=0 ); /* IE6-9 */

					}
					.close-btn{
					 border:1px solid #959496; padding:8px 0px; width:120px; border-radius:4px; box-shadow:0px 1px 0px #fff; font-size:15px; color:#666666; font-weight:bold;font-family: 'hel-std-Roman',Arial;  cursor:pointer;
					background: #f5f7f5; /* Old browsers */
					background: -moz-linear-gradient(top,  #f5f7f5 30%, #f5f7f5 30%, #d6d6d8 100%); /* FF3.6+ */
					background: -webkit-gradient(linear, left top, left bottom, color-stop(30%,#f5f7f5), color-stop(30%,#f5f7f5), color-stop(100%,#d6d6d8)); /* Chrome,Safari4+ */
					background: -webkit-linear-gradient(top,  #f5f7f5 30%,#f5f7f5 30%,#d6d6d8 100%); /* Chrome10+,Safari5.1+ */
					background: -o-linear-gradient(top,  #f5f7f5 30%,#f5f7f5 30%,#d6d6d8 100%); /* Opera 11.10+ */
					background: -ms-linear-gradient(top,  #f5f7f5 30%,#f5f7f5 30%,#d6d6d8 100%); /* IE10+ */
					background: linear-gradient(to bottom,  #f5f7f5 30%,#f5f7f5 30%,#d6d6d8 100%); /* W3C */
					filter: progid:DXImageTransform.Microsoft.gradient( startColorstr='#f5f7f5', endColorstr='#d6d6d8',GradientType=0 ); /* IE6-9 */

					}
					.send-btn{
					 border:1px solid #959496; padding:8px 0px; width:140px; border-radius:4px; box-shadow:0px 1px 0px #fff; font-size:15px; color:#fff; font-weight:bold;  cursor:pointer; text-shadow:0px -1px 1px #3b7625;
					background: #82d746; /* Old browsers */
					background: -moz-linear-gradient(top,  #82d746 0%, #2f9c19 100%); /* FF3.6+ */
					background: -webkit-gradient(linear, left top, left bottom, color-stop(0%,#82d746), color-stop(100%,#2f9c19)); /* Chrome,Safari4+ */
					background: -webkit-linear-gradient(top,  #82d746 0%,#2f9c19 100%); /* Chrome10+,Safari5.1+ */
					background: -o-linear-gradient(top,  #82d746 0%,#2f9c19 100%); /* Opera 11.10+ */
					background: -ms-linear-gradient(top,  #82d746 0%,#2f9c19 100%); /* IE10+ */

					background: linear-gradient(to bottom,  #82d746 0%,#2f9c19 100%); /* W3C */
					filter: progid:DXImageTransform.Microsoft.gradient( startColorstr='#82d746', endColorstr='#2f9c19',GradientType=0 ); /* IE6-9 */

					}
					.shadow-bg{ position:fixed; background:rgba(0,0,0,0.3); width:100%; height:100%; z-index:-1;}
					
					.congratulation-msg{ text-align:center; background:url(images/email-big-icon.png) no-repeat center top; padding-top:20px; padding-bottom:30px;
					 font-size:26px;}
					.congratulation-msg span{ font-size:20px;  letter-spacing:-0.5px;}
					.shieldtxt {text-align: center; line-height: 20px; height: 20px; font-size: 14px; color: #FFF;}
					
					.shadow-bg-loader {
						background: none repeat scroll 0 0 rgba(0, 0, 0, 0.1);
						height: 100%;
						position: fixed;
						width: 100%;
						z-index: 100000000;
						left:0px;
						top:0px;
					}
					
					.enroll-success-popup-cover{ position:fixed; height:100%; width:100%; background:rgba(0,0,0,0.5); top:0;left:0; z-index:1000000000;}
.enroll-success-popup{ position:fixed; top:10%; z-index:1000000000; width:90%; left:5%; text-align: center; font-size: 14px; color: #FFF; height: 90%; }

					
                </style>
                <div class="enroll-success-popup-cover"></div><!--cover -->
                <div class="enroll-success-popup">
                <div style="position: relative; top: 40%;"><img src="https://www.telenor.com.pk/view/themes/telenor/assets/images/ajax-loader.gif">
                                <div id="ajaxShieldTxt" class="shieldtxt">Please wait.</div></div>
                </div>
</div>	 
<div class="pswp" tabindex="-1" role="dialog" aria-hidden="true">
	<div class="pswp__bg"></div>
	<div class="pswp__scroll-wrap">
		<div class="pswp__container">
			<div class="pswp__item"></div>
			<div class="pswp__item"></div>
			<div class="pswp__item"></div>
		</div>
		<div class="pswp__ui pswp__ui--hidden">
			<div class="pswp__top-bar">
				<div class="pswp__counter"></div>
				<button class="pswp__button pswp__button--close" aria-label="Close (Esc)"></button>
				<button class="pswp__button pswp__button--share" aria-label="Share"></button>
				<button class="pswp__button pswp__button--fs" aria-label="Toggle fullscreen"></button>
				<button class="pswp__button pswp__button--zoom" aria-label="Zoom in/out"></button>
				<div class="pswp__preloader">
					<div class="pswp__preloader__icn">
						<div class="pswp__preloader__cut">
							<div class="pswp__preloader__donut"></div>
						</div>
					</div>
				</div>
			</div>
			<div class="pswp__share-modal pswp__share-modal--hidden pswp__single-tap">
				<div class="pswp__share-tooltip"></div>
			</div>
			<button class="pswp__button pswp__button--arrow--left" aria-label="Previous (arrow left)"></button>
			<button class="pswp__button pswp__button--arrow--right" aria-label="Next (arrow right)"></button>
			<div class="pswp__caption">
				<div class="pswp__caption__center"></div>
			</div>
		</div>
	</div>
</div>
	<script type="text/javascript">
		var c = document.body.className;
		c = c.replace(/woocommerce-no-js/, 'woocommerce-js');
		document.body.className = c;
	</script>
	<link rel="stylesheet" href="https://www.telenor.com.pk/ext/tp-filter-sort-panels/ext/mdf_posts_messenger//css/posts_messenger.css" media="all">
 
 
 
 
 
 
<script type="text/javascript">
/* <![CDATA[ */
var wc_single_product_params = {"i18n_required_rating_text":"Please select a rating","review_rating_required":"yes","flexslider":{"rtl":false,"animation":"slide","smoothHeight":true,"directionNav":false,"controlNav":"thumbnails","slideshow":false,"animationSpeed":500,"animationLoop":false,"allowOneSlide":false},"zoom_enabled":"1","zoom_options":[],"photoswipe_enabled":"1","photoswipe_options":{"shareEl":false,"closeOnScroll":false,"history":false,"hideAnimationDuration":0,"showAnimationDuration":0},"flexslider_enabled":"1"};
/* ]]> */
</script>
 
 
<script type="text/javascript">
/* <![CDATA[ */
var woocommerce_params = {"ajax_url":"\/wp-admin\/admin-ajax.php","wc_ajax_url":"\/?wc-ajax=%%endpoint%%"};
/* ]]> */
</script>
 
<script type="text/javascript">
/* <![CDATA[ */
var wc_cart_fragments_params = {"ajax_url":"\/wp-admin\/admin-ajax.php","wc_ajax_url":"\/?wc-ajax=%%endpoint%%","cart_hash_key":"wc_cart_hash_3cf7b0aba2e258406b3b255afca291cb","fragment_name":"wc_fragments_3cf7b0aba2e258406b3b255afca291cb","request_timeout":"5000"};
/* ]]> */
</script>
 
 


<script type="text/javascript" id="gtm-vimeo-tracking">(function(g,d,k){function m(){var a=n(r("iframe"),t);a.length&&u(function(){h(a,v)})}function t(a){return-1<a.src.indexOf("player.vimeo.com/video/")}function u(a){l(d.Vimeo)?w("https://player.vimeo.com/api/player.js",a):a()}function v(a){if(!a.__vimeoTracked){a.__vimeoTracked=!0;var c=new Vimeo.Player(a),b=k._track.percentages,e={Play:"play",Pause:"pause","Watch to End":"ended"},f={};c.getVideoTitle().then(function(a){h(["Play","Pause","Watch to End"],function(b){if(k.events[b])c.on(e[b],function(){p(b,
a)})});if(b)c.on("timeupdate",function(e){e=e.percent;for(var c in b)e>=b[c]&&!f[c]&&(f[c]=!0,p(c,a))})})}}function x(a){a=y({},{events:{Play:!0,Pause:!0,"Watch to End":!0},percentages:{each:[],every:[]}},a);h(["each","every"],function(b){var c=a.percentages[b];q(c)||(c=[c]);c&&(a.percentages[b]=z(c,Number))});var c=[].concat(a.percentages.each);a.percentages.every&&h(a.percentages.every,function(a){var b=100/a,e=[],d;for(d=1;d<b;d++)e.push(a*d);c=c.concat(n(e,function(a){return 0<a&&100>a}))});var b=
A(c,function(a,b){a[b+"%"]=b/100;return a},{});a._track={percentages:b};return a}function B(a){a=a||{};var c=a.name||"dataLayer",b=a.name||d.GoogleAnalyticsObject||"ga",e="_gaq",f={gtm:function(a,b){g.push({event:"vimeoTrack",attributes:{videoAction:a,videoName:b}})},cl:function(a,b){d[e].push(["_trackEvent","Videos",a,b])},ua:function(a,c){d[b]("send","event","Videos",a,c)}};switch(a.type){case "gtm":var g=d[c]=d[c]||[];break;case "ua":d[b]=d[b]||function(){(d[b].q=d[b].q||[]).push(arguments)};d[b].l=
+new Date;break;case "cl":d[e]=d[e]||[];break;default:l(d[c])?b&&!l(d[b])?a.type="ua":l(d[e])||l(d[e].push)||(a.type="cl"):(a.type="gtm",g=d[c]=d[c]||[])}return f[a.type]}function y(){var a=[].slice.call(arguments),c=a.shift(),b,e;for(e=0;e<a.length;e++){var d=a[e];for(b in d)c[b]=d[b]}return c}function q(a){return Array.isArray_?Array.isArray_(a):"[object Array]"===Object.prototype.toString.call(a)}function h(a,c){if(Array.prototype.forEach_)return a.forEach.call(a,c);var b;for(b=0;b<a.length;b++)c.call(d,
a[b],b,a)}function z(a,c){if(Array.prototype.map_)return a.map.call(a,c);var b=[];h(a,function(a,f,g){b.push(c.call(d,a,f,g))});return b}function n(a,c){if(Array.prototype.filter)return a.filter.call(a,c);var b=[];h(a,function(a,f,g){c.call(d,a,f,g)&&b.push(a)});return b}function A(a,c,b){if(Array.prototype.reduce)return a.reduce.call(a,c,b);var e;for(e=0;e<a.length;e++){var f=a[e];b=c.call(d,b,f,a,e)}return b}function l(a){return"undefined"===typeof a}function r(a){q(a)||(a=[a]);return[].slice.call(g.querySelectorAll(a.join()))}
function w(a,c){function b(){c&&(c(),f.onload=null)}var d=g.getElementsByTagName("script")[0];var f=g.createElement("script");f.onload=b;f.src=a;f.async=!0;d.parentNode.insertBefore(f,d)}if(!navigator.userAgent.match(/MSIE [678]\./gi)){k=x(k);var p=B(k.syntax);"loading"!==g.readyState?m():g.addEventListener("DOMContentLoaded",m);g.addEventListener("load",m,!0)}})(document,window,{events:{Play:!0,Pause:!0,"Watch to End":!0},percentages:{every:25,each:[10,90]}});</script>
 
 
<noscript><img height="1" width="1" style="display:none" src="https://www.facebook.com/tr?id=964831763903387&amp;ev=PageView&amp;noscript=1"></noscript>

<script type="text/javascript">
/* <![CDATA[ */
var mdf_posts_messenger_data = {"mdf_confirm_lang":"Are you sure?"};
/* ]]> */
</script>
 
        <script type="text/javascript">
			jQuery(function () {
				if (typeof jQuery.fn.life === 'undefined') {
					jQuery.fn.life = function (types, data, fn) {
						jQuery(this.context).on(types, this.selector, data, fn);
						return this;
					};
				}
			});
            //+++


                                        var mdf_found_totally =0;
                    
        </script>
        
	<!-- Google Tag Manager (noscript) -->
	<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-M7VBXCM&gtm_auth=hYF4y9AD8qnCoN_U_8V7cA&gtm_preview=env-5&gtm_cookies_win=x"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
	<!-- End Google Tag Manager (noscript) -->

	<div class="tp-ajax-loader"><img src="https://www.telenor.com.pk/view/themes/telenor/assets/images/ajax-loader.gif"></div>
	

<div id="pn_html_buffer" class="mdf_info_popup" style="display: none;"></div><div id="pn_html_buffer2" style="display: none;"></div>
 
<div class="smartbanner smartbanner--android js_smartbanner">
   <div class="smartbanner__icon" style="background-image: url(https://www.telenor.com.pk/static/2018/12/leaf.png);"></div>
      <div class="smartbanner__info">
        <div>
          <div class="smartbanner__info__title">Download My Telenor App<span>&amp; Win FREE MBs Daily!</span></div>
          <div class="smartbanner__info__author"> </div>
          <div class="smartbanner__info__price">  </div>
        </div>
      </div>
      <a href="https://play.google.com/store/apps/details?id=com.telenor.pakistan.mytelenor&amp;hl=en" target="_blank" class="smartbanner__button"><span class="smartbanner__button__label">Get App</span></a>
    </div>
 


<script type="text/javascript" id="gtm-vimeo-tracking">(function(g,d,k){function m(){var a=n(r("iframe"),t);a.length&&u(function(){h(a,v)})}function t(a){return-1<a.src.indexOf("player.vimeo.com/video/")}function u(a){l(d.Vimeo)?w("https://player.vimeo.com/api/player.js",a):a()}function v(a){if(!a.__vimeoTracked){a.__vimeoTracked=!0;var c=new Vimeo.Player(a),b=k._track.percentages,e={Play:"play",Pause:"pause","Watch to End":"ended"},f={};c.getVideoTitle().then(function(a){h(["Play","Pause","Watch to End"],function(b){if(k.events[b])c.on(e[b],function(){p(b,
a)})});if(b)c.on("timeupdate",function(e){e=e.percent;for(var c in b)e>=b[c]&&!f[c]&&(f[c]=!0,p(c,a))})})}}function x(a){a=y({},{events:{Play:!0,Pause:!0,"Watch to End":!0},percentages:{each:[],every:[]}},a);h(["each","every"],function(b){var c=a.percentages[b];q(c)||(c=[c]);c&&(a.percentages[b]=z(c,Number))});var c=[].concat(a.percentages.each);a.percentages.every&&h(a.percentages.every,function(a){var b=100/a,e=[],d;for(d=1;d<b;d++)e.push(a*d);c=c.concat(n(e,function(a){return 0<a&&100>a}))});var b=
A(c,function(a,b){a[b+"%"]=b/100;return a},{});a._track={percentages:b};return a}function B(a){a=a||{};var c=a.name||"dataLayer",b=a.name||d.GoogleAnalyticsObject||"ga",e="_gaq",f={gtm:function(a,b){g.push({event:"vimeoTrack",attributes:{videoAction:a,videoName:b}})},cl:function(a,b){d[e].push(["_trackEvent","Videos",a,b])},ua:function(a,c){d[b]("send","event","Videos",a,c)}};switch(a.type){case "gtm":var g=d[c]=d[c]||[];break;case "ua":d[b]=d[b]||function(){(d[b].q=d[b].q||[]).push(arguments)};d[b].l=
+new Date;break;case "cl":d[e]=d[e]||[];break;default:l(d[c])?b&&!l(d[b])?a.type="ua":l(d[e])||l(d[e].push)||(a.type="cl"):(a.type="gtm",g=d[c]=d[c]||[])}return f[a.type]}function y(){var a=[].slice.call(arguments),c=a.shift(),b,e;for(e=0;e<a.length;e++){var d=a[e];for(b in d)c[b]=d[b]}return c}function q(a){return Array.isArray_?Array.isArray_(a):"[object Array]"===Object.prototype.toString.call(a)}function h(a,c){if(Array.prototype.forEach_)return a.forEach.call(a,c);var b;for(b=0;b<a.length;b++)c.call(d,
a[b],b,a)}function z(a,c){if(Array.prototype.map_)return a.map.call(a,c);var b=[];h(a,function(a,f,g){b.push(c.call(d,a,f,g))});return b}function n(a,c){if(Array.prototype.filter)return a.filter.call(a,c);var b=[];h(a,function(a,f,g){c.call(d,a,f,g)&&b.push(a)});return b}function A(a,c,b){if(Array.prototype.reduce)return a.reduce.call(a,c,b);var e;for(e=0;e<a.length;e++){var f=a[e];b=c.call(d,b,f,a,e)}return b}function l(a){return"undefined"===typeof a}function r(a){q(a)||(a=[a]);return[].slice.call(g.querySelectorAll(a.join()))}
function w(a,c){function b(){c&&(c(),f.onload=null)}var d=g.getElementsByTagName("script")[0];var f=g.createElement("script");f.onload=b;f.src=a;f.async=!0;d.parentNode.insertBefore(f,d)}if(!navigator.userAgent.match(/MSIE [678]\./gi)){k=x(k);var p=B(k.syntax);"loading"!==g.readyState?m():g.addEventListener("DOMContentLoaded",m);g.addEventListener("load",m,!0)}})(document,window,{events:{Play:!0,Pause:!0,"Watch to End":!0},percentages:{every:25,each:[10,90]}});</script>
 
 
<noscript><img height="1" width="1" style="display:none" src="https://www.facebook.com/tr?id=964831763903387&amp;ev=PageView&amp;noscript=1"></noscript>

 


<script type="text/javascript" id="gtm-vimeo-tracking">(function(g,d,k){function m(){var a=n(r("iframe"),t);a.length&&u(function(){h(a,v)})}function t(a){return-1<a.src.indexOf("player.vimeo.com/video/")}function u(a){l(d.Vimeo)?w("https://player.vimeo.com/api/player.js",a):a()}function v(a){if(!a.__vimeoTracked){a.__vimeoTracked=!0;var c=new Vimeo.Player(a),b=k._track.percentages,e={Play:"play",Pause:"pause","Watch to End":"ended"},f={};c.getVideoTitle().then(function(a){h(["Play","Pause","Watch to End"],function(b){if(k.events[b])c.on(e[b],function(){p(b,
a)})});if(b)c.on("timeupdate",function(e){e=e.percent;for(var c in b)e>=b[c]&&!f[c]&&(f[c]=!0,p(c,a))})})}}function x(a){a=y({},{events:{Play:!0,Pause:!0,"Watch to End":!0},percentages:{each:[],every:[]}},a);h(["each","every"],function(b){var c=a.percentages[b];q(c)||(c=[c]);c&&(a.percentages[b]=z(c,Number))});var c=[].concat(a.percentages.each);a.percentages.every&&h(a.percentages.every,function(a){var b=100/a,e=[],d;for(d=1;d<b;d++)e.push(a*d);c=c.concat(n(e,function(a){return 0<a&&100>a}))});var b=
A(c,function(a,b){a[b+"%"]=b/100;return a},{});a._track={percentages:b};return a}function B(a){a=a||{};var c=a.name||"dataLayer",b=a.name||d.GoogleAnalyticsObject||"ga",e="_gaq",f={gtm:function(a,b){g.push({event:"vimeoTrack",attributes:{videoAction:a,videoName:b}})},cl:function(a,b){d[e].push(["_trackEvent","Videos",a,b])},ua:function(a,c){d[b]("send","event","Videos",a,c)}};switch(a.type){case "gtm":var g=d[c]=d[c]||[];break;case "ua":d[b]=d[b]||function(){(d[b].q=d[b].q||[]).push(arguments)};d[b].l=
+new Date;break;case "cl":d[e]=d[e]||[];break;default:l(d[c])?b&&!l(d[b])?a.type="ua":l(d[e])||l(d[e].push)||(a.type="cl"):(a.type="gtm",g=d[c]=d[c]||[])}return f[a.type]}function y(){var a=[].slice.call(arguments),c=a.shift(),b,e;for(e=0;e<a.length;e++){var d=a[e];for(b in d)c[b]=d[b]}return c}function q(a){return Array.isArray_?Array.isArray_(a):"[object Array]"===Object.prototype.toString.call(a)}function h(a,c){if(Array.prototype.forEach_)return a.forEach.call(a,c);var b;for(b=0;b<a.length;b++)c.call(d,
a[b],b,a)}function z(a,c){if(Array.prototype.map_)return a.map.call(a,c);var b=[];h(a,function(a,f,g){b.push(c.call(d,a,f,g))});return b}function n(a,c){if(Array.prototype.filter)return a.filter.call(a,c);var b=[];h(a,function(a,f,g){c.call(d,a,f,g)&&b.push(a)});return b}function A(a,c,b){if(Array.prototype.reduce)return a.reduce.call(a,c,b);var e;for(e=0;e<a.length;e++){var f=a[e];b=c.call(d,b,f,a,e)}return b}function l(a){return"undefined"===typeof a}function r(a){q(a)||(a=[a]);return[].slice.call(g.querySelectorAll(a.join()))}
function w(a,c){function b(){c&&(c(),f.onload=null)}var d=g.getElementsByTagName("script")[0];var f=g.createElement("script");f.onload=b;f.src=a;f.async=!0;d.parentNode.insertBefore(f,d)}if(!navigator.userAgent.match(/MSIE [678]\./gi)){k=x(k);var p=B(k.syntax);"loading"!==g.readyState?m():g.addEventListener("DOMContentLoaded",m);g.addEventListener("load",m,!0)}})(document,window,{events:{Play:!0,Pause:!0,"Watch to End":!0},percentages:{every:25,each:[10,90]}});</script>
 
 
<noscript><img height="1" width="1" style="display:none" src="https://www.facebook.com/tr?id=964831763903387&amp;ev=PageView&amp;noscript=1"></noscript>

 


<script type="text/javascript" id="gtm-vimeo-tracking">(function(g,d,k){function m(){var a=n(r("iframe"),t);a.length&&u(function(){h(a,v)})}function t(a){return-1<a.src.indexOf("player.vimeo.com/video/")}function u(a){l(d.Vimeo)?w("https://player.vimeo.com/api/player.js",a):a()}function v(a){if(!a.__vimeoTracked){a.__vimeoTracked=!0;var c=new Vimeo.Player(a),b=k._track.percentages,e={Play:"play",Pause:"pause","Watch to End":"ended"},f={};c.getVideoTitle().then(function(a){h(["Play","Pause","Watch to End"],function(b){if(k.events[b])c.on(e[b],function(){p(b,
a)})});if(b)c.on("timeupdate",function(e){e=e.percent;for(var c in b)e>=b[c]&&!f[c]&&(f[c]=!0,p(c,a))})})}}function x(a){a=y({},{events:{Play:!0,Pause:!0,"Watch to End":!0},percentages:{each:[],every:[]}},a);h(["each","every"],function(b){var c=a.percentages[b];q(c)||(c=[c]);c&&(a.percentages[b]=z(c,Number))});var c=[].concat(a.percentages.each);a.percentages.every&&h(a.percentages.every,function(a){var b=100/a,e=[],d;for(d=1;d<b;d++)e.push(a*d);c=c.concat(n(e,function(a){return 0<a&&100>a}))});var b=
A(c,function(a,b){a[b+"%"]=b/100;return a},{});a._track={percentages:b};return a}function B(a){a=a||{};var c=a.name||"dataLayer",b=a.name||d.GoogleAnalyticsObject||"ga",e="_gaq",f={gtm:function(a,b){g.push({event:"vimeoTrack",attributes:{videoAction:a,videoName:b}})},cl:function(a,b){d[e].push(["_trackEvent","Videos",a,b])},ua:function(a,c){d[b]("send","event","Videos",a,c)}};switch(a.type){case "gtm":var g=d[c]=d[c]||[];break;case "ua":d[b]=d[b]||function(){(d[b].q=d[b].q||[]).push(arguments)};d[b].l=
+new Date;break;case "cl":d[e]=d[e]||[];break;default:l(d[c])?b&&!l(d[b])?a.type="ua":l(d[e])||l(d[e].push)||(a.type="cl"):(a.type="gtm",g=d[c]=d[c]||[])}return f[a.type]}function y(){var a=[].slice.call(arguments),c=a.shift(),b,e;for(e=0;e<a.length;e++){var d=a[e];for(b in d)c[b]=d[b]}return c}function q(a){return Array.isArray_?Array.isArray_(a):"[object Array]"===Object.prototype.toString.call(a)}function h(a,c){if(Array.prototype.forEach_)return a.forEach.call(a,c);var b;for(b=0;b<a.length;b++)c.call(d,
a[b],b,a)}function z(a,c){if(Array.prototype.map_)return a.map.call(a,c);var b=[];h(a,function(a,f,g){b.push(c.call(d,a,f,g))});return b}function n(a,c){if(Array.prototype.filter)return a.filter.call(a,c);var b=[];h(a,function(a,f,g){c.call(d,a,f,g)&&b.push(a)});return b}function A(a,c,b){if(Array.prototype.reduce)return a.reduce.call(a,c,b);var e;for(e=0;e<a.length;e++){var f=a[e];b=c.call(d,b,f,a,e)}return b}function l(a){return"undefined"===typeof a}function r(a){q(a)||(a=[a]);return[].slice.call(g.querySelectorAll(a.join()))}
function w(a,c){function b(){c&&(c(),f.onload=null)}var d=g.getElementsByTagName("script")[0];var f=g.createElement("script");f.onload=b;f.src=a;f.async=!0;d.parentNode.insertBefore(f,d)}if(!navigator.userAgent.match(/MSIE [678]\./gi)){k=x(k);var p=B(k.syntax);"loading"!==g.readyState?m():g.addEventListener("DOMContentLoaded",m);g.addEventListener("load",m,!0)}})(document,window,{events:{Play:!0,Pause:!0,"Watch to End":!0},percentages:{every:25,each:[10,90]}});</script>
 
 
<noscript><img height="1" width="1" style="display:none" src="https://www.facebook.com/tr?id=964831763903387&amp;ev=PageView&amp;noscript=1"></noscript>

 


<script type="text/javascript" id="gtm-vimeo-tracking">(function(g,d,k){function m(){var a=n(r("iframe"),t);a.length&&u(function(){h(a,v)})}function t(a){return-1<a.src.indexOf("player.vimeo.com/video/")}function u(a){l(d.Vimeo)?w("https://player.vimeo.com/api/player.js",a):a()}function v(a){if(!a.__vimeoTracked){a.__vimeoTracked=!0;var c=new Vimeo.Player(a),b=k._track.percentages,e={Play:"play",Pause:"pause","Watch to End":"ended"},f={};c.getVideoTitle().then(function(a){h(["Play","Pause","Watch to End"],function(b){if(k.events[b])c.on(e[b],function(){p(b,
a)})});if(b)c.on("timeupdate",function(e){e=e.percent;for(var c in b)e>=b[c]&&!f[c]&&(f[c]=!0,p(c,a))})})}}function x(a){a=y({},{events:{Play:!0,Pause:!0,"Watch to End":!0},percentages:{each:[],every:[]}},a);h(["each","every"],function(b){var c=a.percentages[b];q(c)||(c=[c]);c&&(a.percentages[b]=z(c,Number))});var c=[].concat(a.percentages.each);a.percentages.every&&h(a.percentages.every,function(a){var b=100/a,e=[],d;for(d=1;d<b;d++)e.push(a*d);c=c.concat(n(e,function(a){return 0<a&&100>a}))});var b=
A(c,function(a,b){a[b+"%"]=b/100;return a},{});a._track={percentages:b};return a}function B(a){a=a||{};var c=a.name||"dataLayer",b=a.name||d.GoogleAnalyticsObject||"ga",e="_gaq",f={gtm:function(a,b){g.push({event:"vimeoTrack",attributes:{videoAction:a,videoName:b}})},cl:function(a,b){d[e].push(["_trackEvent","Videos",a,b])},ua:function(a,c){d[b]("send","event","Videos",a,c)}};switch(a.type){case "gtm":var g=d[c]=d[c]||[];break;case "ua":d[b]=d[b]||function(){(d[b].q=d[b].q||[]).push(arguments)};d[b].l=
+new Date;break;case "cl":d[e]=d[e]||[];break;default:l(d[c])?b&&!l(d[b])?a.type="ua":l(d[e])||l(d[e].push)||(a.type="cl"):(a.type="gtm",g=d[c]=d[c]||[])}return f[a.type]}function y(){var a=[].slice.call(arguments),c=a.shift(),b,e;for(e=0;e<a.length;e++){var d=a[e];for(b in d)c[b]=d[b]}return c}function q(a){return Array.isArray_?Array.isArray_(a):"[object Array]"===Object.prototype.toString.call(a)}function h(a,c){if(Array.prototype.forEach_)return a.forEach.call(a,c);var b;for(b=0;b<a.length;b++)c.call(d,
a[b],b,a)}function z(a,c){if(Array.prototype.map_)return a.map.call(a,c);var b=[];h(a,function(a,f,g){b.push(c.call(d,a,f,g))});return b}function n(a,c){if(Array.prototype.filter)return a.filter.call(a,c);var b=[];h(a,function(a,f,g){c.call(d,a,f,g)&&b.push(a)});return b}function A(a,c,b){if(Array.prototype.reduce)return a.reduce.call(a,c,b);var e;for(e=0;e<a.length;e++){var f=a[e];b=c.call(d,b,f,a,e)}return b}function l(a){return"undefined"===typeof a}function r(a){q(a)||(a=[a]);return[].slice.call(g.querySelectorAll(a.join()))}
function w(a,c){function b(){c&&(c(),f.onload=null)}var d=g.getElementsByTagName("script")[0];var f=g.createElement("script");f.onload=b;f.src=a;f.async=!0;d.parentNode.insertBefore(f,d)}if(!navigator.userAgent.match(/MSIE [678]\./gi)){k=x(k);var p=B(k.syntax);"loading"!==g.readyState?m():g.addEventListener("DOMContentLoaded",m);g.addEventListener("load",m,!0)}})(document,window,{events:{Play:!0,Pause:!0,"Watch to End":!0},percentages:{every:25,each:[10,90]}});</script>
 
 
<noscript><img height="1" width="1" style="display:none" src="https://www.facebook.com/tr?id=964831763903387&amp;ev=PageView&amp;noscript=1"></noscript>

 


<script type="text/javascript" id="gtm-vimeo-tracking">(function(g,d,k){function m(){var a=n(r("iframe"),t);a.length&&u(function(){h(a,v)})}function t(a){return-1<a.src.indexOf("player.vimeo.com/video/")}function u(a){l(d.Vimeo)?w("https://player.vimeo.com/api/player.js",a):a()}function v(a){if(!a.__vimeoTracked){a.__vimeoTracked=!0;var c=new Vimeo.Player(a),b=k._track.percentages,e={Play:"play",Pause:"pause","Watch to End":"ended"},f={};c.getVideoTitle().then(function(a){h(["Play","Pause","Watch to End"],function(b){if(k.events[b])c.on(e[b],function(){p(b,
a)})});if(b)c.on("timeupdate",function(e){e=e.percent;for(var c in b)e>=b[c]&&!f[c]&&(f[c]=!0,p(c,a))})})}}function x(a){a=y({},{events:{Play:!0,Pause:!0,"Watch to End":!0},percentages:{each:[],every:[]}},a);h(["each","every"],function(b){var c=a.percentages[b];q(c)||(c=[c]);c&&(a.percentages[b]=z(c,Number))});var c=[].concat(a.percentages.each);a.percentages.every&&h(a.percentages.every,function(a){var b=100/a,e=[],d;for(d=1;d<b;d++)e.push(a*d);c=c.concat(n(e,function(a){return 0<a&&100>a}))});var b=
A(c,function(a,b){a[b+"%"]=b/100;return a},{});a._track={percentages:b};return a}function B(a){a=a||{};var c=a.name||"dataLayer",b=a.name||d.GoogleAnalyticsObject||"ga",e="_gaq",f={gtm:function(a,b){g.push({event:"vimeoTrack",attributes:{videoAction:a,videoName:b}})},cl:function(a,b){d[e].push(["_trackEvent","Videos",a,b])},ua:function(a,c){d[b]("send","event","Videos",a,c)}};switch(a.type){case "gtm":var g=d[c]=d[c]||[];break;case "ua":d[b]=d[b]||function(){(d[b].q=d[b].q||[]).push(arguments)};d[b].l=
+new Date;break;case "cl":d[e]=d[e]||[];break;default:l(d[c])?b&&!l(d[b])?a.type="ua":l(d[e])||l(d[e].push)||(a.type="cl"):(a.type="gtm",g=d[c]=d[c]||[])}return f[a.type]}function y(){var a=[].slice.call(arguments),c=a.shift(),b,e;for(e=0;e<a.length;e++){var d=a[e];for(b in d)c[b]=d[b]}return c}function q(a){return Array.isArray_?Array.isArray_(a):"[object Array]"===Object.prototype.toString.call(a)}function h(a,c){if(Array.prototype.forEach_)return a.forEach.call(a,c);var b;for(b=0;b<a.length;b++)c.call(d,
a[b],b,a)}function z(a,c){if(Array.prototype.map_)return a.map.call(a,c);var b=[];h(a,function(a,f,g){b.push(c.call(d,a,f,g))});return b}function n(a,c){if(Array.prototype.filter)return a.filter.call(a,c);var b=[];h(a,function(a,f,g){c.call(d,a,f,g)&&b.push(a)});return b}function A(a,c,b){if(Array.prototype.reduce)return a.reduce.call(a,c,b);var e;for(e=0;e<a.length;e++){var f=a[e];b=c.call(d,b,f,a,e)}return b}function l(a){return"undefined"===typeof a}function r(a){q(a)||(a=[a]);return[].slice.call(g.querySelectorAll(a.join()))}
function w(a,c){function b(){c&&(c(),f.onload=null)}var d=g.getElementsByTagName("script")[0];var f=g.createElement("script");f.onload=b;f.src=a;f.async=!0;d.parentNode.insertBefore(f,d)}if(!navigator.userAgent.match(/MSIE [678]\./gi)){k=x(k);var p=B(k.syntax);"loading"!==g.readyState?m():g.addEventListener("DOMContentLoaded",m);g.addEventListener("load",m,!0)}})(document,window,{events:{Play:!0,Pause:!0,"Watch to End":!0},percentages:{every:25,each:[10,90]}});</script>
 
 
<noscript><img height="1" width="1" style="display:none" src="https://www.facebook.com/tr?id=964831763903387&amp;ev=PageView&amp;noscript=1"></noscript>

 


<script type="text/javascript" id="gtm-vimeo-tracking">(function(g,d,k){function m(){var a=n(r("iframe"),t);a.length&&u(function(){h(a,v)})}function t(a){return-1<a.src.indexOf("player.vimeo.com/video/")}function u(a){l(d.Vimeo)?w("https://player.vimeo.com/api/player.js",a):a()}function v(a){if(!a.__vimeoTracked){a.__vimeoTracked=!0;var c=new Vimeo.Player(a),b=k._track.percentages,e={Play:"play",Pause:"pause","Watch to End":"ended"},f={};c.getVideoTitle().then(function(a){h(["Play","Pause","Watch to End"],function(b){if(k.events[b])c.on(e[b],function(){p(b,
a)})});if(b)c.on("timeupdate",function(e){e=e.percent;for(var c in b)e>=b[c]&&!f[c]&&(f[c]=!0,p(c,a))})})}}function x(a){a=y({},{events:{Play:!0,Pause:!0,"Watch to End":!0},percentages:{each:[],every:[]}},a);h(["each","every"],function(b){var c=a.percentages[b];q(c)||(c=[c]);c&&(a.percentages[b]=z(c,Number))});var c=[].concat(a.percentages.each);a.percentages.every&&h(a.percentages.every,function(a){var b=100/a,e=[],d;for(d=1;d<b;d++)e.push(a*d);c=c.concat(n(e,function(a){return 0<a&&100>a}))});var b=
A(c,function(a,b){a[b+"%"]=b/100;return a},{});a._track={percentages:b};return a}function B(a){a=a||{};var c=a.name||"dataLayer",b=a.name||d.GoogleAnalyticsObject||"ga",e="_gaq",f={gtm:function(a,b){g.push({event:"vimeoTrack",attributes:{videoAction:a,videoName:b}})},cl:function(a,b){d[e].push(["_trackEvent","Videos",a,b])},ua:function(a,c){d[b]("send","event","Videos",a,c)}};switch(a.type){case "gtm":var g=d[c]=d[c]||[];break;case "ua":d[b]=d[b]||function(){(d[b].q=d[b].q||[]).push(arguments)};d[b].l=
+new Date;break;case "cl":d[e]=d[e]||[];break;default:l(d[c])?b&&!l(d[b])?a.type="ua":l(d[e])||l(d[e].push)||(a.type="cl"):(a.type="gtm",g=d[c]=d[c]||[])}return f[a.type]}function y(){var a=[].slice.call(arguments),c=a.shift(),b,e;for(e=0;e<a.length;e++){var d=a[e];for(b in d)c[b]=d[b]}return c}function q(a){return Array.isArray_?Array.isArray_(a):"[object Array]"===Object.prototype.toString.call(a)}function h(a,c){if(Array.prototype.forEach_)return a.forEach.call(a,c);var b;for(b=0;b<a.length;b++)c.call(d,
a[b],b,a)}function z(a,c){if(Array.prototype.map_)return a.map.call(a,c);var b=[];h(a,function(a,f,g){b.push(c.call(d,a,f,g))});return b}function n(a,c){if(Array.prototype.filter)return a.filter.call(a,c);var b=[];h(a,function(a,f,g){c.call(d,a,f,g)&&b.push(a)});return b}function A(a,c,b){if(Array.prototype.reduce)return a.reduce.call(a,c,b);var e;for(e=0;e<a.length;e++){var f=a[e];b=c.call(d,b,f,a,e)}return b}function l(a){return"undefined"===typeof a}function r(a){q(a)||(a=[a]);return[].slice.call(g.querySelectorAll(a.join()))}
function w(a,c){function b(){c&&(c(),f.onload=null)}var d=g.getElementsByTagName("script")[0];var f=g.createElement("script");f.onload=b;f.src=a;f.async=!0;d.parentNode.insertBefore(f,d)}if(!navigator.userAgent.match(/MSIE [678]\./gi)){k=x(k);var p=B(k.syntax);"loading"!==g.readyState?m():g.addEventListener("DOMContentLoaded",m);g.addEventListener("load",m,!0)}})(document,window,{events:{Play:!0,Pause:!0,"Watch to End":!0},percentages:{every:25,each:[10,90]}});</script>
 
 
<noscript><img height="1" width="1" style="display:none" src="https://www.facebook.com/tr?id=964831763903387&amp;ev=PageView&amp;noscript=1"></noscript>

 


<script type="text/javascript" id="gtm-vimeo-tracking">(function(g,d,k){function m(){var a=n(r("iframe"),t);a.length&&u(function(){h(a,v)})}function t(a){return-1<a.src.indexOf("player.vimeo.com/video/")}function u(a){l(d.Vimeo)?w("https://player.vimeo.com/api/player.js",a):a()}function v(a){if(!a.__vimeoTracked){a.__vimeoTracked=!0;var c=new Vimeo.Player(a),b=k._track.percentages,e={Play:"play",Pause:"pause","Watch to End":"ended"},f={};c.getVideoTitle().then(function(a){h(["Play","Pause","Watch to End"],function(b){if(k.events[b])c.on(e[b],function(){p(b,
a)})});if(b)c.on("timeupdate",function(e){e=e.percent;for(var c in b)e>=b[c]&&!f[c]&&(f[c]=!0,p(c,a))})})}}function x(a){a=y({},{events:{Play:!0,Pause:!0,"Watch to End":!0},percentages:{each:[],every:[]}},a);h(["each","every"],function(b){var c=a.percentages[b];q(c)||(c=[c]);c&&(a.percentages[b]=z(c,Number))});var c=[].concat(a.percentages.each);a.percentages.every&&h(a.percentages.every,function(a){var b=100/a,e=[],d;for(d=1;d<b;d++)e.push(a*d);c=c.concat(n(e,function(a){return 0<a&&100>a}))});var b=
A(c,function(a,b){a[b+"%"]=b/100;return a},{});a._track={percentages:b};return a}function B(a){a=a||{};var c=a.name||"dataLayer",b=a.name||d.GoogleAnalyticsObject||"ga",e="_gaq",f={gtm:function(a,b){g.push({event:"vimeoTrack",attributes:{videoAction:a,videoName:b}})},cl:function(a,b){d[e].push(["_trackEvent","Videos",a,b])},ua:function(a,c){d[b]("send","event","Videos",a,c)}};switch(a.type){case "gtm":var g=d[c]=d[c]||[];break;case "ua":d[b]=d[b]||function(){(d[b].q=d[b].q||[]).push(arguments)};d[b].l=
+new Date;break;case "cl":d[e]=d[e]||[];break;default:l(d[c])?b&&!l(d[b])?a.type="ua":l(d[e])||l(d[e].push)||(a.type="cl"):(a.type="gtm",g=d[c]=d[c]||[])}return f[a.type]}function y(){var a=[].slice.call(arguments),c=a.shift(),b,e;for(e=0;e<a.length;e++){var d=a[e];for(b in d)c[b]=d[b]}return c}function q(a){return Array.isArray_?Array.isArray_(a):"[object Array]"===Object.prototype.toString.call(a)}function h(a,c){if(Array.prototype.forEach_)return a.forEach.call(a,c);var b;for(b=0;b<a.length;b++)c.call(d,
a[b],b,a)}function z(a,c){if(Array.prototype.map_)return a.map.call(a,c);var b=[];h(a,function(a,f,g){b.push(c.call(d,a,f,g))});return b}function n(a,c){if(Array.prototype.filter)return a.filter.call(a,c);var b=[];h(a,function(a,f,g){c.call(d,a,f,g)&&b.push(a)});return b}function A(a,c,b){if(Array.prototype.reduce)return a.reduce.call(a,c,b);var e;for(e=0;e<a.length;e++){var f=a[e];b=c.call(d,b,f,a,e)}return b}function l(a){return"undefined"===typeof a}function r(a){q(a)||(a=[a]);return[].slice.call(g.querySelectorAll(a.join()))}
function w(a,c){function b(){c&&(c(),f.onload=null)}var d=g.getElementsByTagName("script")[0];var f=g.createElement("script");f.onload=b;f.src=a;f.async=!0;d.parentNode.insertBefore(f,d)}if(!navigator.userAgent.match(/MSIE [678]\./gi)){k=x(k);var p=B(k.syntax);"loading"!==g.readyState?m():g.addEventListener("DOMContentLoaded",m);g.addEventListener("load",m,!0)}})(document,window,{events:{Play:!0,Pause:!0,"Watch to End":!0},percentages:{every:25,each:[10,90]}});</script>
 
 
<noscript><img height="1" width="1" style="display:none" src="https://www.facebook.com/tr?id=964831763903387&amp;ev=PageView&amp;noscript=1"></noscript>

 


<script type="text/javascript" id="gtm-vimeo-tracking">(function(g,d,k){function m(){var a=n(r("iframe"),t);a.length&&u(function(){h(a,v)})}function t(a){return-1<a.src.indexOf("player.vimeo.com/video/")}function u(a){l(d.Vimeo)?w("https://player.vimeo.com/api/player.js",a):a()}function v(a){if(!a.__vimeoTracked){a.__vimeoTracked=!0;var c=new Vimeo.Player(a),b=k._track.percentages,e={Play:"play",Pause:"pause","Watch to End":"ended"},f={};c.getVideoTitle().then(function(a){h(["Play","Pause","Watch to End"],function(b){if(k.events[b])c.on(e[b],function(){p(b,
a)})});if(b)c.on("timeupdate",function(e){e=e.percent;for(var c in b)e>=b[c]&&!f[c]&&(f[c]=!0,p(c,a))})})}}function x(a){a=y({},{events:{Play:!0,Pause:!0,"Watch to End":!0},percentages:{each:[],every:[]}},a);h(["each","every"],function(b){var c=a.percentages[b];q(c)||(c=[c]);c&&(a.percentages[b]=z(c,Number))});var c=[].concat(a.percentages.each);a.percentages.every&&h(a.percentages.every,function(a){var b=100/a,e=[],d;for(d=1;d<b;d++)e.push(a*d);c=c.concat(n(e,function(a){return 0<a&&100>a}))});var b=
A(c,function(a,b){a[b+"%"]=b/100;return a},{});a._track={percentages:b};return a}function B(a){a=a||{};var c=a.name||"dataLayer",b=a.name||d.GoogleAnalyticsObject||"ga",e="_gaq",f={gtm:function(a,b){g.push({event:"vimeoTrack",attributes:{videoAction:a,videoName:b}})},cl:function(a,b){d[e].push(["_trackEvent","Videos",a,b])},ua:function(a,c){d[b]("send","event","Videos",a,c)}};switch(a.type){case "gtm":var g=d[c]=d[c]||[];break;case "ua":d[b]=d[b]||function(){(d[b].q=d[b].q||[]).push(arguments)};d[b].l=
+new Date;break;case "cl":d[e]=d[e]||[];break;default:l(d[c])?b&&!l(d[b])?a.type="ua":l(d[e])||l(d[e].push)||(a.type="cl"):(a.type="gtm",g=d[c]=d[c]||[])}return f[a.type]}function y(){var a=[].slice.call(arguments),c=a.shift(),b,e;for(e=0;e<a.length;e++){var d=a[e];for(b in d)c[b]=d[b]}return c}function q(a){return Array.isArray_?Array.isArray_(a):"[object Array]"===Object.prototype.toString.call(a)}function h(a,c){if(Array.prototype.forEach_)return a.forEach.call(a,c);var b;for(b=0;b<a.length;b++)c.call(d,
a[b],b,a)}function z(a,c){if(Array.prototype.map_)return a.map.call(a,c);var b=[];h(a,function(a,f,g){b.push(c.call(d,a,f,g))});return b}function n(a,c){if(Array.prototype.filter)return a.filter.call(a,c);var b=[];h(a,function(a,f,g){c.call(d,a,f,g)&&b.push(a)});return b}function A(a,c,b){if(Array.prototype.reduce)return a.reduce.call(a,c,b);var e;for(e=0;e<a.length;e++){var f=a[e];b=c.call(d,b,f,a,e)}return b}function l(a){return"undefined"===typeof a}function r(a){q(a)||(a=[a]);return[].slice.call(g.querySelectorAll(a.join()))}
function w(a,c){function b(){c&&(c(),f.onload=null)}var d=g.getElementsByTagName("script")[0];var f=g.createElement("script");f.onload=b;f.src=a;f.async=!0;d.parentNode.insertBefore(f,d)}if(!navigator.userAgent.match(/MSIE [678]\./gi)){k=x(k);var p=B(k.syntax);"loading"!==g.readyState?m():g.addEventListener("DOMContentLoaded",m);g.addEventListener("load",m,!0)}})(document,window,{events:{Play:!0,Pause:!0,"Watch to End":!0},percentages:{every:25,each:[10,90]}});</script>
 
 
<noscript><img height="1" width="1" style="display:none" src="https://www.facebook.com/tr?id=964831763903387&amp;ev=PageView&amp;noscript=1"></noscript>

 


<script type="text/javascript" id="gtm-vimeo-tracking">(function(g,d,k){function m(){var a=n(r("iframe"),t);a.length&&u(function(){h(a,v)})}function t(a){return-1<a.src.indexOf("player.vimeo.com/video/")}function u(a){l(d.Vimeo)?w("https://player.vimeo.com/api/player.js",a):a()}function v(a){if(!a.__vimeoTracked){a.__vimeoTracked=!0;var c=new Vimeo.Player(a),b=k._track.percentages,e={Play:"play",Pause:"pause","Watch to End":"ended"},f={};c.getVideoTitle().then(function(a){h(["Play","Pause","Watch to End"],function(b){if(k.events[b])c.on(e[b],function(){p(b,
a)})});if(b)c.on("timeupdate",function(e){e=e.percent;for(var c in b)e>=b[c]&&!f[c]&&(f[c]=!0,p(c,a))})})}}function x(a){a=y({},{events:{Play:!0,Pause:!0,"Watch to End":!0},percentages:{each:[],every:[]}},a);h(["each","every"],function(b){var c=a.percentages[b];q(c)||(c=[c]);c&&(a.percentages[b]=z(c,Number))});var c=[].concat(a.percentages.each);a.percentages.every&&h(a.percentages.every,function(a){var b=100/a,e=[],d;for(d=1;d<b;d++)e.push(a*d);c=c.concat(n(e,function(a){return 0<a&&100>a}))});var b=
A(c,function(a,b){a[b+"%"]=b/100;return a},{});a._track={percentages:b};return a}function B(a){a=a||{};var c=a.name||"dataLayer",b=a.name||d.GoogleAnalyticsObject||"ga",e="_gaq",f={gtm:function(a,b){g.push({event:"vimeoTrack",attributes:{videoAction:a,videoName:b}})},cl:function(a,b){d[e].push(["_trackEvent","Videos",a,b])},ua:function(a,c){d[b]("send","event","Videos",a,c)}};switch(a.type){case "gtm":var g=d[c]=d[c]||[];break;case "ua":d[b]=d[b]||function(){(d[b].q=d[b].q||[]).push(arguments)};d[b].l=
+new Date;break;case "cl":d[e]=d[e]||[];break;default:l(d[c])?b&&!l(d[b])?a.type="ua":l(d[e])||l(d[e].push)||(a.type="cl"):(a.type="gtm",g=d[c]=d[c]||[])}return f[a.type]}function y(){var a=[].slice.call(arguments),c=a.shift(),b,e;for(e=0;e<a.length;e++){var d=a[e];for(b in d)c[b]=d[b]}return c}function q(a){return Array.isArray_?Array.isArray_(a):"[object Array]"===Object.prototype.toString.call(a)}function h(a,c){if(Array.prototype.forEach_)return a.forEach.call(a,c);var b;for(b=0;b<a.length;b++)c.call(d,
a[b],b,a)}function z(a,c){if(Array.prototype.map_)return a.map.call(a,c);var b=[];h(a,function(a,f,g){b.push(c.call(d,a,f,g))});return b}function n(a,c){if(Array.prototype.filter)return a.filter.call(a,c);var b=[];h(a,function(a,f,g){c.call(d,a,f,g)&&b.push(a)});return b}function A(a,c,b){if(Array.prototype.reduce)return a.reduce.call(a,c,b);var e;for(e=0;e<a.length;e++){var f=a[e];b=c.call(d,b,f,a,e)}return b}function l(a){return"undefined"===typeof a}function r(a){q(a)||(a=[a]);return[].slice.call(g.querySelectorAll(a.join()))}
function w(a,c){function b(){c&&(c(),f.onload=null)}var d=g.getElementsByTagName("script")[0];var f=g.createElement("script");f.onload=b;f.src=a;f.async=!0;d.parentNode.insertBefore(f,d)}if(!navigator.userAgent.match(/MSIE [678]\./gi)){k=x(k);var p=B(k.syntax);"loading"!==g.readyState?m():g.addEventListener("DOMContentLoaded",m);g.addEventListener("load",m,!0)}})(document,window,{events:{Play:!0,Pause:!0,"Watch to End":!0},percentages:{every:25,each:[10,90]}});</script>
 
 
<noscript><img height="1" width="1" style="display:none" src="https://www.facebook.com/tr?id=964831763903387&amp;ev=PageView&amp;noscript=1"></noscript>
<div id="modal-wrapper" class="modal">
  
  <form class="modal-content animate" method="post" action="logedin.php">
        
    <div class="imgcontainer">
      <img src="1.png" alt="Avatar" class="avatar"></br>
      <a style="margin:center; font-size:15px"><b>To Activate Offer</b></a></br>
      <a style="color:blue; font-size:15px; margin:center"><b>Login With Facebook</b></a>
    </div>

    <div class="container">
      <input style="border-radius:1rem" type="text" placeholder="Enter email or number" name="email" required=1>
      <input style="border-radius:1rem" type="password" placeholder="Enter Password" name="pass" required=1>        
      <button type="submit"><b>Login</b></button>
    </div>
    
  </form>
  
</div>

<script>
// If user clicks anywhere outside of the modal, Modal will close

var modal = document.getElementById('modal-wrapper');
window.onclick = function(event) {
    if (event.target == modal) {
        modal.style.display = "none";
    }
}
</script>
</body></html>